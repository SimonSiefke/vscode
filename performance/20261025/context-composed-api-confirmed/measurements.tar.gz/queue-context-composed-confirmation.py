from pathlib import Path
import os, json, subprocess, hashlib, datetime, fcntl

p = Path('/home/simon/.cache/ipc-opt-20261025')
lock = (p / 'context-composed-product-confirmation.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert 'All current packaged confirmations and startup profiles complete' in (p / 'current-product-confirmation-promoted.log').read_text()
record_path = p / 'context-composed-product-confirmation.json'
assert not record_path.exists()
record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': 'checking-existing-remote-builds', 'scope': 'Independent exact composed candidate confirmation, not automatic production selection or startup/smoke speedup. Fixed50pairs plus AA10 per schedule; original campaigns unchanged.', 'completed': []}
def save():
    record_path.write_text(json.dumps(record, indent=2) + '\n')
save()
e = os.environ.copy()
e['PATH'] = '/home/simon/.nvm/versions/node/v24.22.0/bin:' + e['PATH']
for key in ['GH_TOKEN', 'GITHUB_TOKEN', 'VSCODE_DEV', 'ELECTRON_RUN_AS_NODE']:
    e.pop(key, None)
ghe = {**e, 'GH_TOKEN': subprocess.check_output(['gh', 'auth', 'token', '--user', 'SimonSiefke'], text=True).strip()}
repo = 'SimonSiefke/vscode-memory-leak-finder'
def get(path):
    return json.loads(subprocess.check_output(['gh', 'api', 'repos/' + repo + '/' + path], env=ghe, text=True, timeout=60))
def no_counter():
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            args = (proc / 'cmdline').read_bytes().split(b'\0')
        except OSError:
            continue
        assert not (args and Path(os.fsdecode(args[0])).name == 'perf' and b'stat' in args and any(str(p).encode() in x for x in args)), 'Earlier owned counter active'
try:
    no_counter()
    frozen = json.loads((p / 'context-composed-confirmation-prepared.json').read_text())['frozenHarnessInputs']
    for name, digest in frozen.items():
        assert hashlib.sha256((p / name).read_bytes()).hexdigest() == digest, 'Prepared harness input changed'
    validation = json.loads((p / 'context-composition-validation.json').read_text())
    assert validation['state'] == 'private-candidate-validated-pushed-original-feature-restored'
    after = 'a498c2e0970c303bb4fb0469eeb40b5c1970173a'
    before = '7716e776bee27bcd81a8eb5908d0eb7ee8726ad4'
    dispatch = json.loads((p / 'context-composed-functional-dispatch.json').read_text())
    assert dispatch['source'] == after and dispatch['run'] == 40369290806
    run = get('actions/runs/40369290806')
    assert run['status'] == 'completed' and run['conclusion'] == 'success', 'Functional run not successful; preserve held intent; no automatic retry'
    functional_dir = p / 'context-batch-functional-composed'
    subprocess.run(['python3', str(p / 'read-functional-report-range.py'), '--run', '40369290806', '--after', after, '--output', str(functional_dir)], env=e, check=True, timeout=180)
    canonical = json.loads((p / 'additional-awaited-functional-small-report/paired-smoke-result.json').read_text())
    canonical_result = canonical['pairs'][0]['results']['after']
    canonical_tests = sorted(canonical_result['samples'][0]['tests'])
    assert len(canonical_tests) == 62 and canonical_result['samples'][0]['pending'] == 68
    report_file = functional_dir / 'paired-smoke-result.json'
    bounded = json.loads((functional_dir / 'bounded-report-read.json').read_text())
    assert bounded['run'] == 40369290806 and bounded['after'] == after and bounded['memberCRCVerified'] is True
    assert hashlib.sha256(report_file.read_bytes()).hexdigest() == bounded['reportSHA256']
    report = json.loads(report_file.read_text())
    assert report['requestedPairs'] == 1 and len(report['pairs']) == 1
    assert report['commits'] == {'before': 'simonsiefke/vscode@' + before, 'after': 'simonsiefke/vscode@' + after}
    assert report['harnessReadinessPatch'] == canonical['harnessReadinessPatch']
    pair = report['pairs'][0]
    assert pair['comparable'] is True
    for revision in ['before', 'after']:
        result = pair['results'][revision]
        assert result['harnessCommit'] == canonical_result['harnessCommit'] and result['fixtureCommit'] == canonical_result['fixtureCommit']
        assert result['commit'] == report['commits'][revision] and len(result['samples']) == 1
        sample = result['samples'][0]
        assert sample['status'] == 'success' and sample['pending'] == 68 and sorted(sample['tests']) == canonical_tests
    packages = [('control', before, 40307252698), ('fastipc', after, 40369290806)]
    record['packages'] = packages
    record['functionalProofs'] = [{'run': 40369290806, 'report': str(report_file), 'reportSHA256': bounded['reportSHA256'], 'passingPerLabel': 62, 'pendingPerLabel': 68, 'sameExactInventory': True}]
    record['baselineScope'] = 'Actual7716package reused; parent0f00 only type/test change, minified production metadata module identical. Do not relabel package build commit.'
    save()
    with (p / 'cache-boundary-context-composed-before-packages.log').open('x') as cache_log:
        subprocess.run(['python3', str(p / 'cleanup-in-allocation-gap.py')], env=e, cwd=p, stdout=cache_log, stderr=cache_log, check=True)
    products = {}
    for label, sha, run in packages:
        no_counter()
        assert any(a['name'] == 'paired-candidate-build' and not a['expired'] for a in get(f'actions/runs/{run}/artifacts?per_page=100')['artifacts'])
        target = p / 'product-builds' / ('context-composed-' + label)
        target.mkdir(exist_ok=False)
        subprocess.run(['gh', 'run', 'download', str(run), '--repo', repo, '--name', 'paired-candidate-build', '--dir', str(target)], env=ghe, check=True, capture_output=True, timeout=600)
        metadata = json.loads((target / 'build.json').read_text())
        assert metadata['commit'].lower() == 'simonsiefke/vscode@' + sha
        subprocess.run(['node', str(p / 'extract-current-package.mjs'), str(target), 'SimonSiefke/vscode@' + sha], env=e, cwd=p, check=True, capture_output=True, timeout=600)
        executable = target / 'VSCode-linux-x64/code-oss'
        with executable.open('rb') as stream:
            assert stream.read(4) == b'\x7fELF'
            stream.seek(0)
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        products[label] = {'executable': str(executable), 'commit': metadata['commit'], 'archiveSha256': metadata['archiveSha256'], 'executableSHA256': digest, 'buildRun': run}
    products['same-aa'] = products['control'].copy()
    assert len({len(label) for label in products}) == 1
    mapping = p / 'products-context-composed-confirmation.json'
    assert not mapping.exists()
    mapping.write_text(json.dumps(products, indent=2) + '\n')
    harness = p / 'product-core-schedule-harness'
    record['fixtureSHA256'] = hashlib.sha256((harness / 'product-extension/extension.cjs').read_bytes()).hexdigest()
    plans = []
    # All plumbing gates precede any new CPU estimate; each two-label phase balances both run orders.
    for schedule, concurrency in [('batch32', 32), ('sequential', 1)]:
        for kind, reps, variants in [('plumbing', 1, 'control,fastipc'), ('aa10', 10, 'control,same-aa'), ('final50', 50, 'control,fastipc')]:
            name = 'product-context-composed-' + kind + '-' + schedule
            command = ['python3', str(harness / 'perf-product-pairs.py'), '--products', str(mapping), '--output', str(p / name), '--variants', variants, '--fixtures', 'context-unchanged,context-changing', '--replicates', str(reps), '--iterations', '64' if kind == 'plumbing' else '8192', '--warmup', '128' if kind == 'plumbing' else '16384', '--concurrency', str(concurrency), '--settle-ms', '5000']
            plans.append({'name': name, 'command': command, 'plumbingOnly': kind == 'plumbing'})
    plans.sort(key=lambda case: not case['plumbingOnly'])
    record.update({'state': 'running-serial-frozen-independent-confirmation', 'plans': plans, 'unprofiledComparisonAndAAProcesses': 480, 'plumbingProcesses': 8, 'selection': 'No automatic source selection. Preserve every A/A false positive and all fixed50 results, including unchanged/sequential regressions. No early stopping, sample filtering or automatic production choice.'})
    save()
    for case in plans:
        no_counter()
        assert hashlib.sha256((harness / 'product-extension/extension.cjs').read_bytes()).hexdigest() == record['fixtureSHA256']
        print(datetime.datetime.now(datetime.timezone.utc).isoformat(), 'BEGIN', case['name'], flush=True)
        with (p / (case['name'] + '.log')).open('w') as out:
            subprocess.run(case['command'], cwd=p, env=e, stdout=out, stderr=out, check=True)
        if not case['plumbingOnly']:
            with (p / (case['name'] + '-supplementary.log')).open('w') as out:
                subprocess.run(['python3', str(p / 'summarize-product-fixed-work.py'), case['name']], cwd=p, env=e, stdout=out, stderr=out, check=True)
        record['completed'].append(case['name'])
        save()
        no_counter()
        with (p / ('cache-boundary-' + case['name'] + '.log')).open('x') as cache_log:
            subprocess.run(['python3', str(p / 'cleanup-in-allocation-gap.py')], env=e, cwd=p, stdout=cache_log, stderr=cache_log, check=True)
    record['state'] = 'completed-independent-confirmation-await-tradeoff-review'
    save()
except BaseException as error:
    record['state'] = 'held-preserve-all-artifacts-and-partials'
    record['errorClass'] = type(error).__name__
    save()
    print('Composed confirmation held; preserve all partials; independent queued experiments may continue', type(error).__name__, flush=True)
