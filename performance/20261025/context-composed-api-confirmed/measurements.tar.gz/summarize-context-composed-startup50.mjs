import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import{comparePairs}from'/home/simon/.cache/ipc-performance-driver-20261025/packages/large-benchmark/src/parts/Statistics/Statistics.ts';
const p='/home/simon/.cache/ipc-opt-20261025',root=p+'/context-composed-startup50-raw',results=[];
assert.equal(JSON.parse(fs.readFileSync(p+'/context-composed-startup50-raw-read.json')).state,'raw-resource-read-validated-all400CPUwindows');
assert(!fs.existsSync(p+'/context-composed-startup50-taskclock-summary.json'),'Preserve original summary; no automatic repeat');
for(const id of fs.readdirSync('/proc')){
 if(!/^\d+$/.test(id))continue;
 let argv;try{argv=fs.readFileSync('/proc/'+id+'/cmdline','utf8').split('\0');}catch{continue;}
 assert(!(path.basename(argv[0]||'')==='perf'&&argv.includes('stat')&&argv.some(x=>x.includes(p))),'Counterfree summary only');
}
for(const directory of fs.readdirSync(root).sort()){
 const file=path.join(root,directory,'result.json');if(!directory.startsWith('large-result-')||!fs.existsSync(file))continue;
 const r=JSON.parse(fs.readFileSync(file));assert.equal(r.commits.before,'simonsiefke/vscode@7716e776bee27bcd81a8eb5908d0eb7ee8726ad4');assert.equal(r.commits.after,'simonsiefke/vscode@a498c2e0970c303bb4fb0469eeb40b5c1970173a');assert.equal(r.samples.length,100);assert(r.samples.every(s=>['success','partial'].includes(s.status)));
 const issues=r.samples.filter(s=>s.status!=='success'||s.diagnostics.length).map(s=>({pair:s.pair,revision:s.revision,status:s.status,diagnostics:s.diagnostics}));
 const before=[],after=[],pairsUsed=[],missingPairs=[];
 for(let pair=0;pair<50;pair++){
  const b=r.samples.find(s=>s.pair===pair&&s.revision==='before'),a=r.samples.find(s=>s.pair===pair&&s.revision==='after');assert(b&&a);
  const bm=b.metrics.find(m=>m.name==='task-clock'),am=a.metrics.find(m=>m.name==='task-clock');
  if(!bm||!am){missingPairs.push({pair,beforeAvailable:!!bm,afterAvailable:!!am,beforeValue:bm?.value??null,afterValue:am?.value??null,beforeDiagnostics:b.diagnostics,afterDiagnostics:a.diagnostics});continue;}
  assert.equal(bm.unit,'ms');assert.equal(am.unit,'ms');before.push(bm.value);after.push(am.value);pairsUsed.push(pair);
 }
 results.push({benchmark:r.benchmark,commits:r.commits,runner:r.runner,requestedPairs:50,completePairs:pairsUsed.length,pairsUsed,missingPairs,issues,allLaunchesHaveCPUMetric:r.samples.every(s=>s.metrics.some(m=>m.name==='task-clock')), missingPss:r.samples.filter(s=>!s.metrics.some(m=>m.name==='peakPss')||!s.metrics.some(m=>m.name==='finalPss')).map(s=>({pair:s.pair,revision:s.revision,diagnostics:s.diagnostics})),metric:'process-tree task-clock',comparison:comparePairs(before,after,'median')});
}
assert.equal(results.length,4);fs.writeFileSync(p+'/context-composed-startup50-taskclock-summary.json',JSON.stringify({rawAllMetricsRetained:true,outlierSamplesExcluded:0,missingMetricPairsPreserved:true,results},null,2));console.log(results.map(r=>({benchmark:r.benchmark.id,pairs:r.completePairs,missing:r.missingPairs.length,change:r.comparison.percentChange,intervalMs:r.comparison.interval,inconclusive:r.comparison.inconclusive,beforeMs:r.comparison.before.median,afterMs:r.comparison.after.median})));
