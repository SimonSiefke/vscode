from pathlib import Path
import sys,json,math,statistics
p=Path('/home/simon/.cache/ipc-opt-20261025');name=sys.argv[1];assert '/'not in name;root=p/name;s=json.loads((root/'summary.json').read_text());n=s['pairedIndependentProcesses'];variants=s['arguments']['variants'].split(',');assert n>=6 and'control'in variants;output=root/'supplementary-fixed-work-summary.json';assert not output.exists();r=-1;tail=0
for i in range(n):
 tail+=math.comb(n,i)/2**n
 if tail<=.025:r=i
 else:break
assert r>=0;result={'diagnosticOnly':s['diagnosticOnly'],'campaign':name,'arguments':s['arguments'],'scope':'Same completed unprofiled public API samples; whole-app inherited hardware counters and elapsed time for fixed completed API work. Instructions measure work, not CPU seconds; elapsed is distinct. No profiler or outlier removal.','intervalMethod':'Conservative95% distribution-free sign/order-statistic interval for median paired log ratio; no multiple-comparison correction. Separate from primary instruction bootstrap summaries.','fixtures':{}}
for fixture in s['fixtures']:
 rows={v:[json.loads((root/f'{i:03}-{fixture}-{v}/result.json').read_text())for i in range(n)]for v in variants};products={}
 for v,data in rows.items():
  assert all(d['measuredLogicalCalls']==s['arguments']['iterations']for d in data);assert len({d['executableSHA256']for d in data})==1;assert len({d['product']['commit']for d in data})==1;products[v]={'commit':data[0]['product']['commit'],'executableSHA256':data[0]['executableSHA256'],'node':data[0]['node'],'vscodeVersion':data[0]['vscodeVersion']}
 metrics={'elapsedMs':lambda d:d['elapsedMs'],'userPlusKernelInstructionsPerCompletedCall':lambda d:sum(d['counters'][m]['count']for m in ['instructions:u','instructions:k'])/d['measuredLogicalCalls']};values={'products':products,'metrics':{}}
 for metric,read in metrics.items():
  entry={'medians':{v:statistics.median(read(d)for d in rows[v])for v in variants},'comparisons':{}}
  for v in variants:
   if v=='control':continue
   ratios=sorted(math.log(read(a)/read(b))for a,b in zip(rows[v],rows['control']));lo,hi=[(math.exp(ratios[i])-1)*100 for i in [r,n-1-r]];entry['comparisons'][v]={'pairs':n,'medianPairedChangePercent':(math.exp(statistics.median(ratios))-1)*100,'intervalPercent':[lo,hi],'inconclusive':lo<=0<=hi}
  values['metrics'][metric]=entry
 result['fixtures'][fixture]=values
output.write_text(json.dumps(result,indent=2));print(json.dumps({f:{m:entry['comparisons']for m,entry in value['metrics'].items()}for f,value in result['fixtures'].items()},indent=2))
