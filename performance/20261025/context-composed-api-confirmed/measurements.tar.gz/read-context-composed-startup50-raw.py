from pathlib import Path
import json,os,subprocess,datetime,hashlib,fcntl
p=Path('/home/simon/.cache/ipc-opt-20261025');lock=(p/'context-composed-startup50-raw.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
root=p/'context-composed-startup50-raw';marker=p/'context-composed-startup50-raw-read.json'
assert not root.exists() and not marker.exists(),'Preserve previous intent/partial raw downloads; reconcile before retry'
def no_counter():
 for proc in Path('/proc').iterdir():
  if not proc.name.isdigit():continue
  try:argv=(proc/'cmdline').read_bytes().split(b'\0')
  except OSError:continue
  assert not(argv and Path(os.fsdecode(argv[0])).name=='perf' and b'stat' in argv and any(str(p).encode() in a for a in argv)), 'Read raw startup resources only in reserved counterfree gap'
no_counter();e=os.environ.copy();e['GH_TOKEN']=subprocess.check_output(['gh','auth','token','--user','SimonSiefke'],text=True).strip();repo='SimonSiefke/vscode-memory-leak-finder'
run=json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/actions/runs/40376152386'],env=e,text=True,timeout=35));assert run['status']=='completed' and run['conclusion']=='success'
items=json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/actions/runs/40376152386/artifacts?per_page=30'],env=e,text=True,timeout=35))['artifacts'];chosen=[a for a in items if a['name'].startswith('large-result-')];assert {a['name'] for a in chosen}=={f'large-result-pair-1-{i}' for i in range(1,5)} and all(not a['expired'] and a['size_in_bytes']<1024*1024 for a in chosen);assert sum(a['size_in_bytes'] for a in chosen)<2*1024*1024
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'prepared-counterfree-raw-resource-read','run':40376152386,'artifacts':[{k:a.get(k) for k in ['id','name','size_in_bytes','digest']} for a in chosen],'wholeArtifactDigestVerified':False,'scope':'All four original raw result bundles, not reruns; preserve every partial, unmatched metric and raw perf/pss/log sample. GitHub CLI downloads/extracts; local file hashes recorded; no independently verified wholeZIPdigest claim.'}
marker.write_text(json.dumps(record,indent=2)+'\n')
try:
 subprocess.run(['gh','run','download','40376152386','--repo',repo,'--pattern','large-result-*','--dir',str(root)],env=e,capture_output=True,check=True,timeout=90)
 no_counter();reports=[];before='simonsiefke/vscode@7716e776bee27bcd81a8eb5908d0eb7ee8726ad4';after='simonsiefke/vscode@a498c2e0970c303bb4fb0469eeb40b5c1970173a'
 for directory in sorted(root.iterdir()):
  if not directory.is_dir():continue
  f=directory/'result.json';r=json.loads(f.read_text());assert r['commits']=={'before':before,'after':after} and r['requestedSamples']==50 and len(r['samples'])==100
  assert r['benchmark']['collector']=='resources' and r['benchmark']['startup'] is True
  assert {(x['pair'],x['revision']) for x in r['samples']}=={(i,s) for i in range(50) for s in ['before','after']}
  assert all(x['status'] in ['success','partial'] for x in r['samples'])
  cpu=[];missing=[];issues=[]
  for x in r['samples']:
   metrics={m['name']:m for m in x['metrics']};m=metrics.get('task-clock');assert m and m['unit']=='ms' and m['value']>0;cpu.append({'pair':x['pair'],'revision':x['revision'],'valueMs':m['value']})
   if 'peakPss' not in metrics or 'finalPss' not in metrics:missing.append({'pair':x['pair'],'revision':x['revision'],'availableMetrics':sorted(metrics),'diagnostics':x['diagnostics']})
   if x['status']!='success' or x['diagnostics']:issues.append({'pair':x['pair'],'revision':x['revision'],'status':x['status'],'diagnostics':x['diagnostics']})
  reports.append({'benchmark':r['benchmark'],'runner':r['runner'],'samples':100,'completeCPUPairs':50,'missingPssOrFinalPss':missing,'issues':issues,'cpuValues':cpu,'rawResultSHA256':hashlib.sha256(f.read_bytes()).hexdigest()})
 assert len(reports)==4 and len({x['benchmark']['id'] for x in reports})==4
 record['state']='raw-resource-read-validated-all400CPUwindows';record['reports']=reports;record['files']=[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in root.rglob('*') if f.is_file() and not f.is_symlink()];record['rawAllMetricsPreserved']=True;marker.write_text(json.dumps(record,indent=2)+'\n');print('All400 startup CPUwindows verified; allPSSpartials/unmatchedsamples preserved. Recompute paired summaries only in same counterfree gap.',flush=True)
except BaseException as error:
 record['state']='held-preserve-partial-resource-read-no-automatic-repeat';record['errorClass']=type(error).__name__;marker.write_text(json.dumps(record,indent=2)+'\n');print(record['state'],record['errorClass'],flush=True);raise SystemExit(1) from None
