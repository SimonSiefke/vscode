from pathlib import Path
import os, json, hashlib, tarfile, subprocess, datetime, fcntl

p = Path('/home/simon/.cache/ipc-opt-20261025')
lock = (p / 'context-composed-api-evidence-preparation.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert json.loads((p / 'context-composed-product-confirmation.json').read_text())['state'] == 'completed-independent-confirmation-await-tradeoff-review'
assert json.loads((p / 'context-composed-review-boundary.json').read_text())['state'] == 'ready-counterfree-review-gap'
gap = json.loads((p / 'context-composed-review-boundary.json').read_text())
assert gap['state'] == 'ready-counterfree-review-gap'
assert not (p / 'context-composed-review-release.json').exists()
assert datetime.datetime.fromisoformat(gap['deadlineUTC']) > datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=5), 'Insufficient reserved review time'
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        args = (proc / 'cmdline').read_bytes().split(b'\0')
    except OSError:
        continue
    assert not (args and Path(os.fsdecode(args[0])).name == 'perf' and b'stat' in args and any(str(p).encode() in a for a in args)), 'Wait for a counter-free serial stage'
archive = p / 'context-composed-api-confirmed.tar.gz'
assert not archive.exists(), 'Preserve completed or interrupted archives; do not automatically repeat'
assert len(json.loads((p / 'context-composed-product-confirmation.json').read_text())['completed']) == 6
harness = p / 'product-core-schedule-harness'
fixture_sha = hashlib.sha256((harness / 'product-extension/extension.cjs').read_bytes()).hexdigest()
assert fixture_sha == json.loads((p / 'context-composed-product-confirmation.json').read_text())['fixtureSHA256']
assert fixture_sha == json.loads((p / 'context-composed-confirmation-prepared.json').read_text())['frozenHarnessInputs']['product-core-schedule-harness/product-extension/extension.cjs']
plan = {'cases':[{**case,'output':case['name']} for case in json.loads((p / 'context-composed-product-confirmation.json').read_text())['plans']]}
products = json.loads((p / 'products-context-composed-confirmation.json').read_text())
assert products['control']['commit'].endswith('@7716e776bee27bcd81a8eb5908d0eb7ee8726ad4')
assert products['fastipc']['commit'].endswith('@a498c2e0970c303bb4fb0469eeb40b5c1970173a')
assert products['same-aa'] == products['control']
for name, expected_sha in json.loads((p / 'context-composed-confirmation-prepared.json').read_text())['frozenHarnessInputs'].items():
    assert hashlib.sha256((p / name).read_bytes()).hexdigest() == expected_sha, 'Frozen input changed'
files, campaigns, counts = [], [], {'unprofiled': 0, 'plumbing': 0, 'rawProfiles': 0}
for case in plan['cases']:
    root = p / case['output']
    command = case['command']
    arg = lambda name: command[command.index('--' + name) + 1]
    expected = int(arg('replicates')) * len(arg('variants').split(',')) * len(arg('fixtures').split(','))
    summary = json.loads((root / 'summary.json').read_text())
    manifest = json.loads((root / 'manifest.json').read_text())
    assert summary['diagnosticOnly'] is False
    for name in ['replicates', 'iterations', 'warmup', 'concurrency']:
        assert summary['arguments'][name] == int(arg(name))
    assert summary['arguments']['variants'] == arg('variants') and summary['arguments']['fixtures'] == arg('fixtures')
    results = sorted(root.glob('*/result.json'))
    assert len(results) == expected and len(manifest['samples']) == expected
    assert {str(f.relative_to(root)) for f in results} == {r['path'] for r in manifest['samples']}
    assert all(r['status'] == 'success' for r in manifest['samples'])
    runtimes = set()
    for result in results:
        row = json.loads(result.read_text())
        assert row['measuredLogicalCalls'] == int(arg('iterations')) and row['fixtureSHA256'] == fixture_sha
        assert row['product'] == products[row['variant']]
        assert row['options']['fixture'] in ['context-changing', 'context-unchanged']
        assert row['executableSHA256'] == products[row['variant']]['executableSHA256']
        assert row['bufferPool'] == 8192 and not (result.parent / 'error.json').exists()
        assert set(row['counters']) == {'instructions:u', 'instructions:k'}
        assert all(value['count'] > 0 and float(value['raw'][4]) >= 99 for value in row['counters'].values())
        runtimes.add((row['node'], row['vscodeVersion']))
        files.extend(result.parent / name for name in ['result.json', 'counts.csv', 'process.log'])
    assert len(runtimes) == 1, 'Keep runtime scopes separate'
    plumbing = case.get('plumbingOnly', False)
    if not plumbing and not (root / 'supplementary-fixed-work-summary.json').exists():
        with (p / (case['output'] + '-archive-supplementary.log')).open('w') as out:
            subprocess.run(['python3', str(p / 'summarize-product-fixed-work.py'), case['output']], cwd=p, stdout=out, stderr=out, check=True)
    files.extend([root / 'manifest.json', root / 'summary.json', p / (case['output'] + '.log')])
    if not plumbing:
        files.append(root / 'supplementary-fixed-work-summary.json')
    counts['plumbing' if plumbing else 'unprofiled'] += expected
    campaigns.append({'campaign': case['output'], 'processes': expected, 'plumbingOnly': plumbing, 'arguments': summary['arguments'], 'observedRuntime': [{'node': a, 'vscodeVersion': b} for a, b in runtimes]})
assert counts['unprofiled'] == 480 and counts['plumbing'] == 8
assert len(json.loads((p / 'context-composed-product-confirmation.json').read_text())['completed']) == 6
for name in ['products-context-composed-confirmation.json', 'context-composed-confirmation-prepared.json', 'queue-context-composed-confirmation.py', 'context-composed-confirmation-controller.log', 'context-composed-product-confirmation.json', 'summarize-product-fixed-work.py', 'context-composition-validation.json', 'context-composed-complete-review.json', 'observed-void-typefix.json', 'context-composed-startup50-raw-read.json', 'context-composed-startup50-taskclock-summary.json', 'context-composed-startup50-summary-analysis.json', 'context-composed-resources50-dispatch.json', 'context-composed-startup50-summary-read.json', 'context-composed-startup50-raw-read-prepared.json', 'read-context-composed-startup50-raw.py', 'summarize-context-composed-startup50.mjs', 'prepare-context-composed-api-evidence.py', 'publish-context-composed-api-evidence.py']:
    files.append(p / name)
files.extend(p.glob('context-composition-after-typefix-*.log'))
files.extend(p / name for name in ['context-composition-before-red.log', 'context-composition-red-build.log', 'context-composed-functional-dispatch.json', 'context-batch-functional-composed/paired-smoke-result.json', 'context-batch-functional-composed/bounded-report-read.json'])
for folder in ['context-composed-startup50-raw', 'context-composed-startup50-summary']:
    assert (p / folder).is_dir()
    files.extend(f for f in (p / folder).rglob('*') if f.is_file() and not f.is_symlink())
for file in harness.rglob('*'):
    if file.is_file() and not file.is_symlink() and file.suffix in ['.py', '.mjs', '.cjs', '.json', '.html'] and '__pycache__' not in file.parts:
        files.append(file)
for variant in ['control', 'fastipc']:
    directory = Path(products[variant]['executable']).parent.parent
    metadata = json.loads((directory / 'build.json').read_text())
    assert metadata['commit'] == products[variant]['commit'] and metadata['archiveSha256'] == products[variant]['archiveSha256']
    files.append(directory / 'build.json')
def sha(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
files = sorted(set(files))
assert all(f.is_file() and not f.is_symlink() and f.resolve().is_relative_to(p) for f in files)
with tarfile.open(archive, 'w:gz', compresslevel=3) as tar:
    for file in files:
        tar.add(file, arcname=str(file.relative_to(p)), recursive=False)
record = {'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Exact actual7716 baseline versus privatea498 composed context candidate. Type-only0f00 parent preserves production module bytes but is not relabelled as the baseline package. Independent A/A10 then fixed50 pairs per batch32/directawait1 schedule, both unchanged/changing publicAPI fixtures. All480 unprofiled+8plumbing launches. Separate original400startup CPUwindows and missingPSS preserved. No pooling/filtering/selective reruns or automatic source selection.', 'counts': counts, 'products': products, 'fixtureSHA256': fixture_sha, 'campaigns': campaigns, 'archiveBytes': archive.stat().st_size, 'archiveSHA256': sha(archive), 'provenanceNote': 'All fixed campaigns complete before bounded counterfree root review. No measured child signalled, paused or repeated. All A/A false positives, regressions, elapsed uncertainty and partial startup metrics retained.', 'files': [{'path': str(f.relative_to(p)), 'bytes': f.stat().st_size, 'sha256': sha(f)} for f in files]}
(p / 'context-composed-api-confirmed-manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Prepared complete current-core API evidence:', counts, len(files), 'files', record['archiveBytes'], 'archive bytes', flush=True)
