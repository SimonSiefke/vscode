from pathlib import Path
import os, json, subprocess, hashlib, datetime, fcntl

p = Path('/home/simon/.cache/ipc-opt-20261025')
v = Path('/home/simon/.cache/vscode-ipc-opt-20261022')
lock = (p / 'context-composed-api-evidence-publication.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not (p / 'context-composed-api-evidence-published.json').exists()
gap = json.loads((p / 'context-composed-review-boundary.json').read_text())
assert gap['state'] == 'ready-counterfree-review-gap'
assert not (p / 'context-composed-review-release.json').exists()
assert datetime.datetime.fromisoformat(gap['deadlineUTC']) > datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=5), 'Insufficient reserved review time'
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        args = (proc / 'cmdline').read_bytes().split(b'\0')
    except OSError:
        continue
    assert not (args and Path(os.fsdecode(args[0])).name == 'perf' and b'stat' in args and any(str(p).encode() in a for a in args)), 'Publish in a counter-free serial stage'
manifest = json.loads((p / 'context-composed-api-confirmed-manifest.json').read_text())
def sha(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
assert sha(p / 'context-composed-api-confirmed.tar.gz') == manifest['archiveSHA256']
for item in manifest['files']:
    assert sha(p / item['path']) == item['sha256'], 'Archived input changed; preserve and review before publishing'
text = """# Composed context batching comparison

The exact packaged comparison is actual `7716e776bee27bcd81a8eb5908d0eb7ee8726ad4` to private candidate `a498c2e0970c303bb4fb0469eeb40b5c1970173a`. The candidate preserves the selected MessagePort scalar codecs, bounded small-message batching and native promises, and coalesces synchronous context-key notifications within physical native RPC packets. Current parent `0f00a7e3` differs from the actual baseline by a type/test correction with byte-identical minified production metadata; the baseline package is not relabelled.

Both unchanged/changing public context-command fixtures run ten independent identical-package A/A pairs followed by fifty fixed before/after pairs per schedule (batch32 and direct await1). All480 unprofiled and8 plumbing launches are retained. Fixed counts, returned results, package hashes, positive counters and running coverage are verified. Startup, warmup and extension-host GC precede each API counting window. No sample exclusions, early stopping, schedule pooling or automatic source selection.

Instructions measure work, not CPU time. Elapsed time is supplementary. Tables show paired median percentage changes and95% intervals. User/kernel intervals are exploratory bootstrap; total/elapsed intervals use conservative sign/order statistics. No multiple-comparison correction. All A/A false positives and inconclusive results remain visible. A small unchanged-context effect comparable to its A/A fluctuation is not attributed to this candidate. This comparison does not establish10–20% whole-product startup or smoke-suite improvements.

"""
items = {'manifest.json': p / 'context-composed-api-confirmed-manifest.json', 'measurements.tar.gz': p / 'context-composed-api-confirmed.tar.gz'}
def cell(entry):
    low, high = entry['intervalPercent']
    suffix = ' (inconclusive)' if entry['inconclusive'] else ''
    return f"{entry['medianPairedChangePercent']:+.3f}% [{low:+.3f}, {high:+.3f}]{suffix}"
for kind, title in [('final50', 'Fixed fifty-pair comparisons'), ('aa10', 'Identical-package A/A controls')]:
    text += '## ' + title + '\n\n| Schedule | Fixture | User instructions | Kernel instructions | Total instructions | Elapsed |\n| --- | --- | --- | --- | --- | --- |\n'
    for case in manifest['campaigns']:
        if case['plumbingOnly'] or kind not in case['campaign']:
            continue
        root = p / case['campaign']
        primary = json.loads((root / 'summary.json').read_text())
        supplementary = json.loads((root / 'supplementary-fixed-work-summary.json').read_text())
        label = 'fastipc' if kind == 'final50' else 'same-aa'
        schedule = 'batch32' if primary['arguments']['concurrency'] == 32 else 'direct await1'
        items[case['campaign'] + '.summary.json'] = root / 'summary.json'
        items[case['campaign'] + '.supplementary.json'] = root / 'supplementary-fixed-work-summary.json'
        for fixture, row in primary['fixtures'].items():
            extra = supplementary['fixtures'][fixture]['metrics']
            values = [row['instructions:u']['comparisons'][label], row['instructions:k']['comparisons'][label], extra['userPlusKernelInstructionsPerCompletedCall']['comparisons'][label], extra['elapsedMs']['comparisons'][label]]
            text += '| ' + ' | '.join([schedule, fixture, *map(cell, values)]) + ' |\n'
    text += '\n'
items['complete-review.json'] = p / 'context-composed-complete-review.json'
text += 'The composed candidate remains private: the large changing-context batch win accompanies a repeated sequential changing-context instruction regression of +0.847% [+0.635%, +0.978%]. Sequential elapsed is inconclusive. A later minimum-batch-size refinement must receive separate tests and independent package measurements. No production source selection is made by this archive.\n\n'
startup = json.loads((p / 'context-composed-startup50-taskclock-summary.json').read_text())
items['startup-taskclock-summary.json'] = p / 'context-composed-startup50-taskclock-summary.json'
text += "## Separate startup resource comparison\n\n[Original workflow run](https://github.com/SimonSiefke/vscode-memory-leak-finder/actions/runs/40376152386) reuses the same exact package builds. Four scenarios each have50 pairs,400 original CPU windows in total. All raw metrics and the missing baseline empty/cold PSS sample with its unmatched after value remain preserved. PSS is resident memory rather than cumulative allocation. Different scenarios, cache policies and hosted runner types are kept separate. These intervals are paired bootstrap median CPU-time differences in milliseconds, distinct from the API instruction/elapsed intervals above.\n\n"
text += '| Scenario | Before CPU ms | After CPU ms | Median change | Paired95% interval ms |\n| --- | ---: | ---: | ---: | --- |\n'
for row in startup['results']:
    c=row['comparison']
    text += '| '+str(row['benchmark']['id'])+' | '+str(c['before']['median'])+' | '+str(c['after']['median'])+' | '+str(c['percentChange'])+'% | '+str(c['interval'])+' |\n'
text += "\nAll fixed campaigns completed before the bounded counterfree source/evidence review. No measured child was signalled, paused or repeated. The archive includes every raw API result, counter CSV, process/controller log, fixture and collector source, package provenance, startup result bundle and partial metric. Named Chromium caches are excluded.\n\n"
text += 'Archive SHA-256: `' + manifest['archiveSHA256'] + '`.\n'
readme = p / 'context-composed-api-evidence-readme.md'
readme.write_text(text)
items['README.md'] = readme
branch = 'perf/ipc-evidence-20261025'
folder = 'performance/20261025/context-composed-api-confirmed'
e = os.environ.copy()
e.pop('GH_TOKEN', None)
e.pop('GITHUB_TOKEN', None)
parent = subprocess.check_output(['git', 'rev-parse', 'refs/heads/' + branch], cwd=v, text=True).strip()
assert not subprocess.check_output(['git', 'ls-tree', parent, folder], cwd=v, text=True).strip(), 'Append-only destination exists'
attributes = subprocess.check_output(['git', 'check-attr', 'filter', '--', *[folder + '/' + name for name in items]], cwd=v, text=True)
assert ': lfs' not in attributes, 'Do not skip an actual LFS upload'
index = p / 'context-composed-api-evidence.index'
assert not index.exists(), 'Preserve interrupted publication index; reconcile before retry'
e['GIT_INDEX_FILE'] = str(index)
subprocess.run(['git', 'read-tree', parent], cwd=v, env=e, check=True)
for name, file in items.items():
    blob = subprocess.check_output(['git', 'hash-object', '-w', '--stdin'], cwd=v, input=file.read_bytes()).decode().strip()
    subprocess.run(['git', 'update-index', '--add', '--cacheinfo', '100644', blob, folder + '/' + name], cwd=v, env=e, check=True)
tree = subprocess.check_output(['git', 'write-tree'], cwd=v, env=e, text=True).strip()
commit = subprocess.check_output(['git', 'commit-tree', tree, '-p', parent], cwd=v, env=e, input='Archive composed context candidate and startup comparison with all controls\n', text=True).strip()
changes = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', commit], cwd=v, text=True).splitlines()
assert len(changes) == len(items) and all(path.startswith(folder + '/') for path in changes)
e.pop('GIT_INDEX_FILE')
e['GH_TOKEN'] = subprocess.check_output(['gh', 'auth', 'token', '--user', 'SimonSiefke'], text=True).strip()
e['GIT_LFS_SKIP_PUSH'] = '1'
git = ['git', '-c', 'credential.helper=', '-c', 'credential.helper=!gh auth git-credential']
remote = subprocess.check_output(git + ['ls-remote', 'https://github.com/SimonSiefke/vscode.git', 'refs/heads/' + branch], cwd=v, env=e, text=True).split()[0]
assert remote == parent, 'Remote evidence advanced; preserve prepared commit/index and reconcile'
subprocess.run(['git', 'update-ref', 'refs/heads/' + branch, commit, parent], cwd=v, check=True)
subprocess.run(git + ['push', 'https://github.com/SimonSiefke/vscode.git', 'refs/heads/' + branch + ':refs/heads/' + branch], cwd=v, env=e, check=True)
status = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commit': commit, 'parent': parent, 'folder': folder, 'archiveSHA256': manifest['archiveSHA256'], 'counts': manifest['counts'], 'action': 'Append-only existing evidence branch publication; no PR operation or feature worktree mutation'}
(p / 'context-composed-api-evidence-published.json').write_text(json.dumps(status, indent=2) + '\n')
progress_file = p / 'progress-current.json'
progress = json.loads(progress_file.read_text())
progress['evidenceHead'] = commit
progress['contextComposedAPIEvidence'] = status
progress_file.write_text(json.dumps(progress, indent=2) + '\n')
print('Published complete composed context candidate evaluation', commit, flush=True)
