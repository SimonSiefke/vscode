import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {mkdir,writeFile} from 'node:fs/promises';
import {createServer} from 'node:net';
import {spawn} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
import {installStartupTrafficHooks} from './startup-traffic-hooks.mjs';
const options=JSON.parse(readFileSync(process.argv[2]));const dir=options.output;await mkdir(dir,{recursive:true});let log='';const sessions=[];let child;
const deadline=setTimeout(()=>{writeFileSync(dir+'/application.log',log);writeFileSync(dir+'/error.json',JSON.stringify({error:'startup profile deadline180s'}));process.exit(124)},180000);
async function freePort(){const server=createServer();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const port=server.address().port;await new Promise(resolve=>server.close(resolve));return port}
async function connect(port,renderer=false){
 for(let attempt=0;attempt<1500;attempt++){
  if(child?.exitCode!==null)throw new Error('Application exited before inspector connection');
  try {
   const response=await fetch(`http://127.0.0.1:${port}/json/list`,{signal:AbortSignal.timeout(1000)});const targets=await response.json();const target=targets.find(t=>t.webSocketDebuggerUrl&&(!renderer||t.type==='page'&&/workbench.*\.html/.test(t.url)));if(!target){await delay(50);continue}
   const socket=new WebSocket(target.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true})});let id=0;const pending=new Map();socket.addEventListener('message',event=>{const data=JSON.parse(event.data);const pair=pending.get(data.id);if(pair){pending.delete(data.id);clearTimeout(pair.timer);data.error?pair.reject(new Error(JSON.stringify(data.error))):pair.resolve(data.result)}});socket.addEventListener('close',()=>{for(const pair of pending.values()){clearTimeout(pair.timer);pair.reject(new Error('Inspector closed'))}pending.clear()});const session={send(method,params={}){return new Promise((resolve,reject)=>{const key=++id;const timer=setTimeout(()=>{pending.delete(key);reject(new Error('Inspector command timeout: '+method))},20000);pending.set(key,{resolve,reject,timer});socket.send(JSON.stringify({id:key,method,params}))})},close(){socket.close()}};sessions.push(session);return session;
  }catch(error){if(attempt===1499)throw error;await delay(50)}
 }
 throw new Error('Inspector unavailable')
}
let exitCode=0;
try {
 const [mainPort,rendererPort,extPort]=await Promise.all([freePort(),freePort(),freePort()]);const marker=dir+'/startup-marker';writeFileSync(marker,'');const args=['--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--disable-extensions','--disable-updates','--disable-telemetry','--disable-background-networking','--disable-component-update','--skip-welcome','--skip-release-notes','--disable-workspace-trust','--force-disable-user-env','--password-store=basic','--locale=en','--ozone-platform=x11','--new-window','--user-data-dir='+dir+'/profile','--extensions-dir='+dir+'/extensions','--shared-data-dir='+dir+'/shared','--inspect-brk='+mainPort,'--remote-debugging-port='+rendererPort,'--inspect-brk-extensions='+extPort,'--prof-startup-prefix='+marker];if(options.workspace)args.push(options.workspace,options.workspace+'/small.txt');const env={...process.env};delete env.ELECTRON_RUN_AS_NODE;delete env.VSCODE_DEV;child=spawn(options.executable,args,{cwd:dir,env,detached:false,stdio:['ignore','pipe','pipe']});child.stdout.on('data',data=>log=(log+data).slice(-4*1024*1024));child.stderr.on('data',data=>log=(log+data).slice(-4*1024*1024));child.on('error',error=>{log+='\n'+error.stack});
 const start=async(port,kind)=>{const renderer=kind==='renderer';const session=await connect(port,renderer);await session.send('Profiler.enable');try{const setup=await session.send('Runtime.evaluate',{expression:'('+installStartupTrafficHooks.toString()+')('+JSON.stringify(kind)+')',returnByValue:true});await writeFile(dir+'/'+kind+'-traffic-setup.json',JSON.stringify(setup,null,2))}catch(error){await writeFile(dir+'/'+kind+'-traffic-setup.json',JSON.stringify({unavailable:String(error.stack)}))}await session.send('Profiler.start');if(!renderer)await session.send('Runtime.runIfWaitingForDebugger');return session};
 const main=await start(mainPort,'main');const [renderer,extensionHost]=await Promise.all([start(rendererPort,'renderer'),start(extPort,'extension-host')]);
 while(existsSync(marker)){if(child.exitCode!==null)throw new Error('Application exited before LifecyclePhase.Eventually marker');await delay(50)}
 for(const [name,session]of [['main',main],['renderer',renderer],['extension-host',extensionHost]]){
  const result=await session.send('Profiler.stop');assertProfile(result.profile,name);await writeFile(dir+'/'+name+'.cpuprofile',JSON.stringify(result.profile));
  let diagnostic;
  try{
   const traffic=await session.send('Runtime.evaluate',{expression:'JSON.stringify(globalThis.__ipcStartupProfileStats)',returnByValue:true});
   const stats=typeof traffic.result?.value==='string'?JSON.parse(traffic.result.value):null;
   const coverage={messagePorts:(stats?.prototypeHooks??0)>0,classicIncoming:stats?.classicIPC?.incomingListener===true,classicOutgoing:(stats?.classicIPC?.outgoingHooks??0)>0};
   diagnostic={diagnosticOnly:true,available:Object.values(coverage).some(Boolean),coverage,stats,exceptionDetails:traffic.exceptionDetails};
  }catch(error){diagnostic={diagnosticOnly:true,available:false,error:String(error.stack)}}
  await writeFile(dir+'/'+name+'-traffic.json',JSON.stringify(diagnostic,null,2));
 }

 await writeFile(dir+'/result.json',JSON.stringify({diagnosticOnly:true,options,profileScope:'Main and extension host inspect-brk start before application JS; renderer attaches as workbench target becomes available and may miss initial page work. Stop at built-in LifecyclePhase.Eventually + installed-extension-registration marker. No-cached-data is not added. Profilers and debugger pauses perturb timing; no performance estimate uses these runs.',trafficScope:'Diagnostic in-process MessagePort, main-process classic IPC receive and WebContents.send hooks; attempted failures counted separately, sender frames/batches/method names/lengths without payload values. Profiling and hooks perturb execution; not included in CPU/timing performance comparisons. Missing hooks remain unavailable, never zero-imputed.',noIssueOrRestartFlow:'Marker is never recreated; application is closed after profiles so no issue/restart action is taken.'},null,2));
 const expression="(async()=>{const electron=typeof require==='function'?require('electron'):process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');electron.app.quit()})()";await main.send('Runtime.evaluate',{expression,awaitPromise:true}).catch(()=>{});
}catch(error){exitCode=1;await writeFile(dir+'/error.json',JSON.stringify({error:String(error.stack)},null,2))}finally{clearTimeout(deadline);for(const session of sessions)session.close();await writeFile(dir+'/application.log',log);if(child?.exitCode===null)child.kill('SIGTERM')}
process.exit(exitCode);
function assertProfile(profile,name){if(!profile?.nodes?.length||!profile.samples?.length)throw new Error('Empty '+name+' startup profile')}
