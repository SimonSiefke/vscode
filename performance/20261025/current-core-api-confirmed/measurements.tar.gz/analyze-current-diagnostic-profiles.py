from pathlib import Path
import sys,json,subprocess,datetime,hashlib
p=Path('/home/simon/.cache/ipc-opt-20261025');scope=sys.argv[1];assert scope in ['startup','workload'];prefix='current-startup-profile-' if scope=='startup' else 'current-workload-profile-';expected=8 if scope=='startup' else json.loads((p/'actual-workload-profile-plan.json').read_text())['newApplicationLaunches']
if scope=='startup':assert 'All current packaged confirmations and startup profiles complete' in (p/'current-product-confirmation-promoted.log').read_text()
else:assert (p/'actual-workload-profiles-complete.json').exists() or (p/'actual-workload-profiles-held.json').exists(),'No completed/held workload diagnostic status yet'
analysis=p/f'current-{scope}-profile-analysis.json';quality=p/f'current-{scope}-profile-coverage.json';assert not analysis.exists() and not quality.exists(),'Preserve earlier diagnostic analysis'
rows=[];profiles=[]
for folder in sorted(p.glob(prefix+'*')):
 if not folder.is_dir():continue
 files=[folder/(name+'.cpuprofile') for name in ['main','renderer','extension-host']];complete=all(f.is_file() for f in files)
 row={'directory':folder.name,'allThreeProfilesPresent':complete,'presentProfiles':[f.name for f in files if f.is_file()]}
 result=folder/'result.json'
 if result.is_file():row['result']=json.loads(result.read_text())
 if scope=='startup':
  opts=json.loads((folder/'options.json').read_text());sha=opts['product']['commit'].rsplit('@',1)[-1];assert sha in ['a167347ebc4ab8923c027674f602a4f74d39ada5','aac6b0fcf3bc6714c8cd7e7dd9fa1bfe6618ba25'];row['sourceProduct']=opts['product'];row['traffic']={}
  for kind in ['main','renderer','extension-host']:
   traffic=folder/(kind+'-traffic.json');setup=folder/(kind+'-traffic-setup.json');row['traffic'][kind]={'available':False,'reason':'Missing diagnostic file'} if not traffic.exists() else json.loads(traffic.read_text());row['traffic'][kind]['setupEnvelope']=json.loads(setup.read_text()) if setup.exists() else {'unavailable':'Missing hook setup file'}
 else:
  manifest=folder/'diagnostic-manifest.json';row['manifest']=json.loads(manifest.read_text()) if manifest.exists() else {'unavailable':'No completed diagnostic manifest'}
 if complete:profiles.extend(files)
 rows.append(row)
if scope=='startup':assert len(rows)==8 and all(row['allThreeProfilesPresent'] for row in rows),'Startup profile collection incomplete; never infer zeros'
if profiles:subprocess.run(['python3',str(p/'summarize-ipc-cpu-profile.py'),str(analysis),*[str(f) for f in profiles]],cwd=p,check=True)
coverage={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'diagnosticOnly':True,'expectedApplicationLaunches':expected,'observedApplicationDirectories':len(rows),'completeLaunches':sum(r['allThreeProfilesPresent'] for r in rows),'analyzedRawProfiles':len(profiles),'missingOrPartialLaunches':expected-sum(r['allThreeProfilesPresent'] for r in rows),'scope':'Separate rawsampledstacksandhookcoverage, not hardwareCPUaccounting or elapsed/startupspeedestimate. Startupmain/extHostdebuggerpausewindowsdiffer; rendererattacheslater. Workloadmain/rendereralsoincludeoutsideextensionhostprofilefinalvalidation. Allrawprofiles/deltas/idle/hookselfweightsretained. Missinghooks/unrecognizednamesdonotimplyzeroIPC. Inclusiveframesoverlap; never sum/subtracthookselfasoverheadcorrection. No automaticproductionselection.','analyzerSHA256':hashlib.sha256((p/'summarize-ipc-cpu-profile.py').read_bytes()).hexdigest(),'rows':rows}
quality.write_text(json.dumps(coverage,indent=2)+'\n');print('Diagnostic coverage',scope,coverage['completeLaunches'],'of',expected,'launches,',len(profiles),'profiles',flush=True)
