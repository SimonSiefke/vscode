from pathlib import Path
import os, json, hashlib, tarfile, subprocess, datetime, fcntl

p = Path('/home/simon/.cache/ipc-opt-20261025')
lock = (p / 'current-core-api-evidence-preparation.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert 'All current packaged confirmations and startup profiles complete' in (p / 'current-product-confirmation-promoted.log').read_text()
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        args = (proc / 'cmdline').read_bytes().split(b'\0')
    except OSError:
        continue
    assert not (args and Path(os.fsdecode(args[0])).name == 'perf' and b'stat' in args and any(str(p).encode() in a for a in args)), 'Wait for a counter-free serial stage'
with (p / 'profile-timing-quality-recovery.log').open('x') as recovery_log:
    subprocess.run(['python3', str(p / 'recover-profile-timing-quality.py')], cwd=p, stdout=recovery_log, stderr=recovery_log, check=True)
archive = p / 'current-core-api-confirmed.tar.gz'
assert not archive.exists(), 'Preserve completed or interrupted archives; do not automatically repeat'
harness = p / 'product-core-schedule-harness'
fixture_sha = hashlib.sha256((harness / 'product-extension/extension.cjs').read_bytes()).hexdigest()
plan = json.loads((p / 'current-product-confirmation-plan.json').read_text())
products = json.loads((p / 'products-current-core.json').read_text())
assert products['control']['commit'].endswith('@a167347ebc4ab8923c027674f602a4f74d39ada5')
assert products['candidate']['commit'].endswith('@aac6b0fcf3bc6714c8cd7e7dd9fa1bfe6618ba25')
assert products['aa-b'] == products['control']
files, campaigns, counts = [], [], {'unprofiled': 0, 'plumbing': 0, 'rawProfiles': 0}
for case in plan['cases']:
    root = p / case['name']
    command = case['command']
    arg = lambda name: command[command.index('--' + name) + 1]
    expected = int(arg('replicates')) * len(arg('variants').split(',')) * len(arg('fixtures').split(','))
    summary = json.loads((root / 'summary.json').read_text())
    manifest = json.loads((root / 'manifest.json').read_text())
    assert summary['diagnosticOnly'] is False
    for name in ['replicates', 'iterations', 'warmup', 'concurrency']:
        assert summary['arguments'][name] == int(arg(name))
    assert summary['arguments']['variants'] == arg('variants') and summary['arguments']['fixtures'] == arg('fixtures')
    results = sorted(root.glob('*/result.json'))
    assert len(results) == expected and len(manifest['samples']) == expected
    assert {str(f.relative_to(root)) for f in results} == {r['path'] for r in manifest['samples']}
    assert all(r['status'] == 'success' for r in manifest['samples'])
    runtimes = set()
    for result in results:
        row = json.loads(result.read_text())
        assert row['measuredLogicalCalls'] == int(arg('iterations')) and row['fixtureSHA256'] == fixture_sha
        assert row['product'] == products[row['variant']]
        assert row['executableSHA256'] == products[row['variant']]['executableSHA256']
        assert row['bufferPool'] == 8192 and not (result.parent / 'error.json').exists()
        assert set(row['counters']) == {'instructions:u', 'instructions:k'}
        assert all(value['count'] > 0 and float(value['raw'][4]) >= 99 for value in row['counters'].values())
        runtimes.add((row['node'], row['vscodeVersion']))
        files.extend(result.parent / name for name in ['result.json', 'counts.csv', 'process.log'])
    assert len(runtimes) == 1, 'Keep runtime scopes separate'
    plumbing = case.get('plumbingOnly', False)
    if not plumbing and not (root / 'supplementary-fixed-work-summary.json').exists():
        with (p / (case['name'] + '-archive-supplementary.log')).open('w') as out:
            subprocess.run(['python3', str(p / 'summarize-product-fixed-work.py'), case['name']], cwd=p, stdout=out, stderr=out, check=True)
    files.extend([root / 'manifest.json', root / 'summary.json', p / (case['name'] + '.log')])
    if not plumbing:
        files.append(root / 'supplementary-fixed-work-summary.json')
    counts['plumbing' if plumbing else 'unprofiled'] += expected
    campaigns.append({'campaign': case['name'], 'processes': expected, 'plumbingOnly': plumbing, 'arguments': summary['arguments'], 'observedRuntime': [{'node': a, 'vscodeVersion': b} for a, b in runtimes]})
assert counts['unprofiled'] == 960 and counts['plumbing'] == 16
for replicate in range(2):
    for scenario in ['empty', 'workspace']:
        for variant in ['control', 'candidate']:
            root = p / f'current-startup-profile-{replicate}-{scenario}-{variant}'
            options = json.loads((root / 'options.json').read_text())
            assert options['product'] == products[variant] and (root / 'result.json').is_file()
            for isolate in ['main', 'renderer', 'extension-host']:
                file = root / (isolate + '.cpuprofile')
                data = json.loads(file.read_text())
                assert data['nodes'] and data['samples']
                files.append(file)
                counts['rawProfiles'] += 1
            files.extend(f for f in root.iterdir() if f.is_file() and f.suffix in ['.json', '.log'])
assert counts['rawProfiles'] == 24
for name in ['products-current-core.json', 'current-product-confirmation-plan.json', 'queue-current-product-confirmation-promoted.py', 'current-product-confirmation-promoted.log', 'startup-profile.mjs', 'startup-traffic-hooks.mjs', 'summarize-product-fixed-work.py', 'summarize-ipc-cpu-profile.py', 'analyze-current-diagnostic-profiles.py', 'prepare-current-core-api-evidence.py', 'publish-current-core-api-evidence.py', 'context-batch-priority-gap.json', 'context-batch-priority-gap.log', 'context-batch-injection-gap.json', 'context-batch-injection-gap.log', 'additional-metadata-priority-gap.json', 'additional-metadata-priority-gap.log', 'metadata-browser-coverage-gap.json', 'metadata-browser-coverage-gap.log', 'metadata-browser-coverage-raw-sample.json', 'metadata-browser-coverage-counts.csv', 'probe-orchestration-gap-ownership/summary.json']:
    files.append(p / name)
for name in ['current-startup-profile-analysis.json', 'current-startup-profile-coverage.json', 'current-startup-profile-analysis.log']:
    if (p / name).is_file():
        files.append(p / name)
files.append(p / 'current-core-sequential-unchanged-distribution-review.json')
files.extend(p / name for name in ['recover-profile-timing-quality.py', 'current-startup-profile-quality-recovery.json', 'profile-timing-quality-recovery.log', 'profile-timing-quality-probe/summary.json'])
for file in harness.rglob('*'):
    if file.is_file() and not file.is_symlink() and file.suffix in ['.py', '.mjs', '.cjs', '.json', '.html'] and '__pycache__' not in file.parts:
        files.append(file)
for variant in ['control', 'candidate']:
    directory = Path(products[variant]['executable']).parent.parent
    metadata = json.loads((directory / 'build.json').read_text())
    assert metadata['commit'] == products[variant]['commit'] and metadata['archiveSha256'] == products[variant]['archiveSha256']
    files.append(directory / 'build.json')
def sha(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
files = sorted(set(files))
assert all(f.is_file() and not f.is_symlink() and f.resolve().is_relative_to(p) for f in files)
with tarfile.open(archive, 'w:gz', compresslevel=3) as tar:
    for file in files:
        tar.add(file, arcname=str(file.relative_to(p)), recursive=False)
record = {'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Exact merged-feature-baseline a167 to selected AAC core public-API increment. Separate independent A/A10 then fixed50 pairs for concurrency32 and direct await1, four fixtures. All960 unprofiled processes and16 plumbing launches retained;24 startup CPU profiles are diagnostics only, excluded from estimates. Nineteen-method264/additional18 metadata and later private prototypes are outside this comparison. No startup/full-smoke speed estimate follows from these API workloads. No outlier filtering, failed-window replacement, or pooling across schedules.', 'counts': counts, 'products': products, 'fixtureSHA256': fixture_sha, 'campaigns': campaigns, 'archiveBytes': archive.stat().st_size, 'archiveSHA256': sha(archive), 'provenanceNote': 'Orchestration-only gaps after whole300/100/20processphases never paused measured children. Second gap log prints300 as inherited typo; its hard assertions and actual manifest require100. Additional missing-browser-coverage gap was at a physically completed pair boundary with only orchestration stopped; raw pre-annotation sample/CSV and ownership probe preserved. No measured child signalled/repeated. Raw logs/journals preserved.', 'files': [{'path': str(f.relative_to(p)), 'bytes': f.stat().st_size, 'sha256': sha(f)} for f in files]}
(p / 'current-core-api-confirmed-manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Prepared complete current-core API evidence:', counts, len(files), 'files', record['archiveBytes'], 'archive bytes', flush=True)
