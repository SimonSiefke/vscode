from pathlib import Path
import collections, datetime, hashlib, importlib.util, json, math, os

ROOT = Path('/home/simon/.cache/ipc-opt-20261025')
ORIGINAL = ROOT / 'summarize-ipc-cpu-profile.py'
spec = importlib.util.spec_from_file_location('original_profile_summary', ORIGINAL)
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)

def summarize_profile(path):
    raw = path.read_bytes()
    data = json.loads(raw)
    nodes = {node['id']: node for node in data['nodes']}
    samples, deltas = data.get('samples', []), data.get('timeDeltas', [])
    assert len(nodes) == len(data['nodes']) and samples
    assert all(sample in nodes for sample in samples)
    parents = {}
    for node in nodes.values():
        for child in node.get('children', []):
            assert child in nodes and child not in parents
            parents[child] = node['id']
    counts = collections.Counter(samples)
    inclusive = collections.Counter()
    named_count = 0
    for leaf, count in counts.items():
        stack, cursor = set(), leaf
        while cursor is not None:
            assert cursor not in stack
            stack.add(cursor)
            inclusive[cursor] += count
            cursor = parents.get(cursor)
        if any(nodes[item]['callFrame']['functionName'] in original.IPC_NAMES for item in stack):
            named_count += count
    bad = [{'index': index, 'value': delta if isinstance(delta, (int, float)) and math.isfinite(delta) else repr(delta)}
           for index, delta in enumerate(deltas)
           if not isinstance(delta, (int, float)) or not math.isfinite(delta) or delta < 0]
    valid = len(samples) == len(deltas) and not bad and sum(deltas) > 0
    def rows(values):
        return [{'nodeId': node, 'function': nodes[node]['callFrame']['functionName'],
                 'url': nodes[node]['callFrame'].get('url', ''), 'samples': count}
                for node, count in values.most_common(40)]
    return {'file': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
            'timingQuality': {'weightedAttributionAvailable': valid, 'samples': len(samples),
                              'deltas': len(deltas), 'invalidDeltas': bad,
                              'policy': 'No clamping, absolute values, omitted negative samples or timestamp repair. Invalid timing disables all weighted attribution for this entire profile.'},
            'unweightedSummary': {'samplesUnderNamedIPCFrames': named_count,
                                  'topSelfFrames': rows(counts), 'topInclusiveFrames': rows(inclusive),
                                  'scope': 'Sample counts only; not CPU time or elapsed time. Inclusive rows overlap. Missing names do not establish zero IPC.'},
            'weightedSummary': original.summarize(path) if valid else None}

def main():
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            args = (proc / 'cmdline').read_bytes().split(b'\0')
        except OSError:
            continue
        assert not (args and Path(os.fsdecode(args[0])).name == 'perf' and b'stat' in args and any(str(ROOT).encode() in arg for arg in args)), 'Recover summaries only in a counter-free serial stage'
    for scope, expected in [('startup', 8), ('workload', 10)]:
        output = ROOT / ('current-' + scope + '-profile-quality-recovery.json')
        profiles = sorted(file for folder in ROOT.glob('current-' + scope + '-profile-*') if folder.is_dir()
                          for file in [folder / (isolate + '.cpuprofile') for isolate in ['main', 'renderer', 'extension-host']] if file.is_file())
        assert profiles and (scope != 'startup' or len(profiles) == 24)
        if output.exists():
            existing = json.loads(output.read_text())
            assert existing['analyzerSHA256'] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
            assert {item['file']: item['sha256'] for item in existing['profiles']} == {str(file): hashlib.sha256(file.read_bytes()).hexdigest() for file in profiles}
            print('Reused immutable quality recovery', scope, flush=True)
            continue
        rows = [summarize_profile(file) for file in profiles]
        report = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'diagnosticOnly': True,
                  'analyzerSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'originalStrictAnalyzerSHA256': hashlib.sha256(ORIGINAL.read_bytes()).hexdigest(),
                  'expectedProfiles': expected * 3, 'presentProfiles': len(rows),
                  'profilesWithUsableNonnegativeTiming': sum(row['timingQuality']['weightedAttributionAvailable'] for row in rows),
                  'scope': 'Separate recovery of already-collected raw profiles. Original strict analyzer, failed analysis logs, raw profiles, deltas, fixtures and all launches remain unchanged. No application/profile rerun or performance estimate. Profiles with invalid timing have unweighted counts only; others retain every original delta, including long/idle/hook weights. No hook-overhead subtraction or pooled CPU-time claim.',
                  'profiles': rows}
        with output.open('x') as stream:
            json.dump(report, stream, indent=2, allow_nan=False)
            stream.write('\n')
        print(scope, len(rows), 'profiles;', report['profilesWithUsableNonnegativeTiming'], 'with usable timing; no raw data changed', flush=True)

if __name__ == '__main__':
    main()
