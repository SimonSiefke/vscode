from pathlib import Path
import os,json,subprocess,time,datetime,fcntl,sys,hashlib
p=Path('/home/simon/.cache/ipc-opt-20261025');d=Path('/home/simon/.cache/ipc-performance-driver-20261025');lock=(p/'current-product-confirmation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);e=os.environ.copy();e['PATH']='/home/simon/.nvm/versions/node/v24.22.0/bin:'+e['PATH'];e.pop('ELECTRON_RUN_AS_NODE',None);e.pop('VSCODE_DEV',None);e.pop('GH_TOKEN',None);e.pop('GITHUB_TOKEN',None);h=p/'product-core-schedule-harness';sys.path.insert(0,str(h));from benchmark_process import run_owned
def verified_executable_sha(path):
 with path.open('rb')as stream:
  assert stream.read(4)==b'\x7fELF'
  stream.seek(0)
  return hashlib.file_digest(stream,'sha256').hexdigest()
print('Promoted serial current-core confirmation: allocation diagnostics must be complete',flush=True)
ready=json.loads((p/'allocation-diagnostics-ready.json').read_text());assert ready['complete']is True
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:args=(proc/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 assert not(args and Path(os.fsdecode(args[0])).name=='perf'and b'stat'in args and any(str(p).encode()in arg for arg in args)),'Earlier counter active'
gh_env={**e,'GH_TOKEN':subprocess.check_output(['gh','auth','token','--user','SimonSiefke'],env=e,text=True,timeout=30).strip()};repo='SimonSiefke/vscode-memory-leak-finder';run=40251176145
while True:
 jobs=json.loads(subprocess.check_output(['gh','api',f'repos/{repo}/actions/runs/{run}/jobs?per_page=100'],env=gh_env,text=True))['jobs'];builds=[j for j in jobs if j['name'].startswith('build (')]
 if any(j['status']=='completed'and j['conclusion']!='success'for j in builds):raise RuntimeError('Current exact package build failed')
 if len(builds)==2 and all(j['status']=='completed'and j['conclusion']=='success'for j in builds):break
 time.sleep(120)
products={}
for variant,sha in [('control','a167347ebc4ab8923c027674f602a4f74d39ada5'),('candidate','aac6b0fcf3bc6714c8cd7e7dd9fa1bfe6618ba25')]:
 target=p/'product-builds'/('combined-'+variant);target.mkdir(exist_ok=False);artifact='large-build-simonsiefke-vscode-'+sha
 subprocess.run(['gh','run','download',str(run),'--repo',repo,'--name',artifact,'--dir',str(target)],env=gh_env,check=True,capture_output=True)
 metadata=json.loads((target/'build.json').read_text());prior=json.loads((p/'combined-build-status'/('before'if variant=='control'else'after')/'status.json').read_text());assert metadata['commit']==prior['commit']and metadata['archiveSha256']==prior['archiveSha256'],'Archived startup package identity changed'
 subprocess.run(['node',str(p/'extract-current-package.mjs'),str(target),'SimonSiefke/vscode@'+sha],env=e,cwd=d,check=True,capture_output=True)
 exe=target/'VSCode-linux-x64/code-oss';products[variant]={'executable':str(exe),'commit':metadata['commit'],'archiveSha256':metadata['archiveSha256'],'executableSHA256':verified_executable_sha(exe),'buildRun':run};print('Verified archived package',variant,sha,flush=True)
products['aa-b']=products['control'].copy();(p/'products-current-core.json').write_text(json.dumps(products,indent=2));plans=[]
for schedule,concurrency in [('batch32',32),('sequential',1)]:
 name='product-current-core-plumbing-'+schedule;cmd=['python3',str(h/'perf-product-pairs.py'),'--products',str(p/'products-current-core.json'),'--output',str(p/name),'--variants','control,candidate','--fixtures','context-unchanged,context-changing,clipboard-64KiB,clipboard-write-64KiB','--replicates','1','--iterations','64','--warmup','128','--concurrency',str(concurrency),'--settle-ms','5000'];plans.append({'name':name,'command':cmd,'plumbingOnly':True})
for schedule,concurrency in [('batch32',32),('sequential',1)]:
 for kind,variants,reps in [('aa10','control,aa-b',10),('final50','control,candidate',50)]:
  for group,fixtures,iters,warm in [('ordinary-read','context-unchanged,context-changing,clipboard-64KiB',32768,16384),('scalar-write','clipboard-write-64KiB',8192,4096)]:
   if concurrency==1:iters,warm=8192,16384
   name='product-current-core-'+group+'-'+kind+('-sequential'if concurrency==1 else'');cmd=['python3',str(h/'perf-product-pairs.py'),'--products',str(p/'products-current-core.json'),'--output',str(p/name),'--variants',variants,'--fixtures',fixtures,'--replicates',str(reps),'--iterations',str(iters),'--warmup',str(warm),'--concurrency',str(concurrency),'--settle-ms','5000'];plans.append({'name':name,'command':cmd})
(p/'current-product-confirmation-plan.json').write_text(json.dumps({'purpose':'Current merged-base packaged core comparison a167 to aac, separate from old original4df to37e cumulative campaign. Independent identical-package A/A10 precedes50fixed pairs for each public API fixture and each schedule. Existingconcurrency32 plans retained; additionalconcurrency1 cases use directawait withoutPromise.all-of-one,8192 measuredafter16384warmup. Bothscopesreportedseparately. Actual scalar-request write and scalar-reply read both covered; whole-app inherited user+kernel counters; no profiler. Nineteen-method metadata264 is outside this exact comparison. Startup diagnostic profiling runs only after all unprofiled counters.','cases':plans},indent=2))
for case in plans:
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'BEGIN',case['name'],flush=True)
 with(p/(case['name']+'.log')).open('w')as out:subprocess.run(case['command'],cwd=p,env=e,stdout=out,stderr=subprocess.STDOUT,check=True)
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'DONE',case['name'],flush=True)
workspace=p/'startup-profile-workspace';workspace.mkdir(exist_ok=False);(workspace/'small.txt').write_text('Native IPC startup profile\n'*100)
for replicate in range(2):
 for scenario in ['empty','workspace']:
  for variant in (['control','candidate']if replicate==0 else['candidate','control']):
   name=f'current-startup-profile-{replicate}-{scenario}-{variant}';target=p/name;target.mkdir(exist_ok=False);options={'output':str(target),'executable':products[variant]['executable'],'product':products[variant],'workspace':str(workspace)if scenario=='workspace'else None};(target/'options.json').write_text(json.dumps(options,indent=2));print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'PROFILE',name,flush=True)
   with(target/'controller.log').open('w')as out:r=run_owned(['xvfb-run','-a','node',str(p/'startup-profile.mjs'),str(target/'options.json')],env=e,cwd=p,stdout=out,stderr=subprocess.STDOUT,timeout=240)
   assert r.returncode==0,(name,r.returncode);assert(target/'result.json').exists();assert all((target/(isolate+'.cpuprofile')).exists()for isolate in ['main','renderer','extension-host'])
print('All current packaged confirmations and startup profiles complete',flush=True)
