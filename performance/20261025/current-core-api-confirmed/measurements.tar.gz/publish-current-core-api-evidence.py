from pathlib import Path
import os, json, subprocess, hashlib, datetime, fcntl

p = Path('/home/simon/.cache/ipc-opt-20261025')
v = Path('/home/simon/.cache/vscode-ipc-opt-20261022')
lock = (p / 'current-core-api-evidence-publication.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not (p / 'current-core-api-evidence-published.json').exists()
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        args = (proc / 'cmdline').read_bytes().split(b'\0')
    except OSError:
        continue
    assert not (args and Path(os.fsdecode(args[0])).name == 'perf' and b'stat' in args and any(str(p).encode() in a for a in args)), 'Publish in a counter-free serial stage'
manifest = json.loads((p / 'current-core-api-confirmed-manifest.json').read_text())
def sha(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
assert sha(p / 'current-core-api-confirmed.tar.gz') == manifest['archiveSHA256']
for item in manifest['files']:
    assert sha(p / item['path']) == item['sha256'], 'Archived input changed; preserve and review before publishing'
text = '''# Current-core public API comparison

This measures the incremental change from [a167](https://github.com/SimonSiefke/vscode/commit/a167347ebc4ab8923c027674f602a4f74d39ada5) to [AAC](https://github.com/SimonSiefke/vscode/commit/aac6b0fcf3bc6714c8cd7e7dd9fa1bfe6618ba25). It is separate from the older original-baseline cumulative results, the nineteen-method metadata followup, later metadata, and all private prototypes. Exact archived application packages and their archive hashes are retained. Their executable hashes can match because the Electron launcher is shared; the archive hashes identify the differing bundled VS Code resources.

Each schedule and fixture has an independent identical-package A/A control with ten pairs, followed by fifty fixed before/after pairs. All 960 unprofiled application processes and 16 plumbing launches are retained. Counts cover inherited application user/kernel retired instructions during fixed completed public API work, after the recorded startup/warmup/GC boundaries. Instructions measure work, not CPU seconds. Elapsed time is distinct. No outlier filtering, missing-window replacement, post-hoc warmup change, or pooling across schedules is used.

The tables show paired median percentage changes and 95% intervals. User/kernel intervals use the primary bootstrap procedure; total instruction and elapsed intervals use the conservative sign/order-statistic procedure. They are descriptive without a multiple-comparison correction. Interpret small apparent wins against the complete A/A controls, whose false positives remain visible.

'''
items = {'manifest.json': p / 'current-core-api-confirmed-manifest.json', 'measurements.tar.gz': p / 'current-core-api-confirmed.tar.gz'}
def cell(entry):
    low, high = entry['intervalPercent']
    suffix = ' (inconclusive)' if entry['inconclusive'] else ''
    return f"{entry['medianPairedChangePercent']:+.3f}% [{low:+.3f}, {high:+.3f}]{suffix}"
for kind, title in [('final50', 'Fixed fifty-pair comparisons'), ('aa10', 'Identical-package A/A controls')]:
    text += '## ' + title + '\n\n| Schedule | Fixture | User instructions | Kernel instructions | Total instructions | Elapsed |\n| --- | --- | --- | --- | --- | --- |\n'
    for case in manifest['campaigns']:
        if case['plumbingOnly'] or kind not in case['campaign']:
            continue
        root = p / case['campaign']
        primary = json.loads((root / 'summary.json').read_text())
        supplementary = json.loads((root / 'supplementary-fixed-work-summary.json').read_text())
        label = 'candidate' if kind == 'final50' else 'aa-b'
        schedule = 'batch32' if primary['arguments']['concurrency'] == 32 else 'direct await1'
        items[case['campaign'] + '.summary.json'] = root / 'summary.json'
        items[case['campaign'] + '.supplementary.json'] = root / 'supplementary-fixed-work-summary.json'
        for fixture, row in primary['fixtures'].items():
            extra = supplementary['fixtures'][fixture]['metrics']
            values = [row['instructions:u']['comparisons'][label], row['instructions:k']['comparisons'][label], extra['userPlusKernelInstructionsPerCompletedCall']['comparisons'][label], extra['elapsedMs']['comparisons'][label]]
            text += '| ' + ' | '.join([schedule, fixture, *map(cell, values)]) + ' |\n'
    text += '\n'
text += '''The direct-await unchanged-context user-instruction samples have distinct process-level bands, also visible in the identical-package control. Its A/A interval is wide (approximately -10.42% to +13.27%). The fixed fifty-pair comparison reports a paired median change of -22.87% [-25.49%, -19.68%], with reductions in both run-order subgroups, but the separate label medians are 395,347 and 371,391 instructions per call. The ratio of those separate medians is a different statistic from the median of paired log-ratios. All samples, both bands, original intervals and an explicit per-pair distribution/order review are retained. No band was filtered, no warmup was changed, and the cause of the bands is not established. This result is not a general latency or startup improvement.

Twenty-four separate CPU profiles from eight empty/private-workspace startup launches are diagnostic sampled stacks only and excluded from every instruction/elapsed estimate. A separate timing-quality recovery preserves the original strict-analysis failure and disables weighted attribution for any entire profile containing invalid timestamp deltas. Such profiles retain unweighted sample counts; negative deltas are never clamped, removed or repaired. Other profiles retain their original timing weights. Their debugger/profile windows differ between isolates; raw profiles, traffic/hook coverage and available analyses are retained. Missing hooks or names do not prove zero IPC, and sampled weights are not hardware CPU accounting. These startup diagnostics do not establish a startup or full smoke-suite speedup.

The complete bundle includes raw sample results, counters, logs, exact fixture/collector scripts and hashes, package metadata, orchestration-only pause/resume journals, all startup profiles and available diagnostic analyses. Only whole campaign orchestration was held at the recorded 300-, 100- and 20-process boundaries; no measured child was paused or repeated. A later missing-browser-coverage repair also held only orchestration until the second-label application child exited successfully; its pre-annotation raw sample, final CSV and disposable ownership/exit-code probe are retained. The second raw coordinator log contains an inherited `300` print typo; its hard assertions and actual manifest require 100 and are preserved unchanged.

'''
text += 'Archive SHA-256: `' + manifest['archiveSHA256'] + '`.\n'
readme = p / 'current-core-api-evidence-readme.md'
readme.write_text(text)
items['README.md'] = readme
branch = 'perf/ipc-evidence-20261025'
folder = 'performance/20261025/current-core-api-confirmed'
e = os.environ.copy()
e.pop('GH_TOKEN', None)
e.pop('GITHUB_TOKEN', None)
parent = subprocess.check_output(['git', 'rev-parse', 'refs/heads/' + branch], cwd=v, text=True).strip()
assert not subprocess.check_output(['git', 'ls-tree', parent, folder], cwd=v, text=True).strip(), 'Append-only destination exists'
attributes = subprocess.check_output(['git', 'check-attr', 'filter', '--', *[folder + '/' + name for name in items]], cwd=v, text=True)
assert ': lfs' not in attributes, 'Do not skip an actual LFS upload'
index = p / 'current-core-api-evidence.index'
assert not index.exists(), 'Preserve interrupted publication index; reconcile before retry'
e['GIT_INDEX_FILE'] = str(index)
subprocess.run(['git', 'read-tree', parent], cwd=v, env=e, check=True)
for name, file in items.items():
    blob = subprocess.check_output(['git', 'hash-object', '-w', '--stdin'], cwd=v, input=file.read_bytes()).decode().strip()
    subprocess.run(['git', 'update-index', '--add', '--cacheinfo', '100644', blob, folder + '/' + name], cwd=v, env=e, check=True)
tree = subprocess.check_output(['git', 'write-tree'], cwd=v, env=e, text=True).strip()
commit = subprocess.check_output(['git', 'commit-tree', tree, '-p', parent], cwd=v, env=e, input='Archive complete current-core public API comparisons and controls\n', text=True).strip()
changes = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', commit], cwd=v, text=True).splitlines()
assert len(changes) == len(items) and all(path.startswith(folder + '/') for path in changes)
e.pop('GIT_INDEX_FILE')
e['GH_TOKEN'] = subprocess.check_output(['gh', 'auth', 'token', '--user', 'SimonSiefke'], text=True).strip()
e['GIT_LFS_SKIP_PUSH'] = '1'
git = ['git', '-c', 'credential.helper=', '-c', 'credential.helper=!gh auth git-credential']
remote = subprocess.check_output(git + ['ls-remote', 'https://github.com/SimonSiefke/vscode.git', 'refs/heads/' + branch], cwd=v, env=e, text=True).split()[0]
assert remote == parent, 'Remote evidence advanced; preserve prepared commit/index and reconcile'
subprocess.run(['git', 'update-ref', 'refs/heads/' + branch, commit, parent], cwd=v, check=True)
subprocess.run(git + ['push', 'https://github.com/SimonSiefke/vscode.git', 'refs/heads/' + branch + ':refs/heads/' + branch], cwd=v, env=e, check=True)
status = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commit': commit, 'parent': parent, 'folder': folder, 'archiveSHA256': manifest['archiveSHA256'], 'counts': manifest['counts'], 'action': 'Append-only existing evidence branch publication; no PR operation or feature worktree mutation'}
(p / 'current-core-api-evidence-published.json').write_text(json.dumps(status, indent=2) + '\n')
progress_file = p / 'progress-current.json'
progress = json.loads(progress_file.read_text())
progress['evidenceHead'] = commit
progress['currentCoreAPIEvidence'] = status
progress_file.write_text(json.dumps(progress, indent=2) + '\n')
print('Published complete current-core API evidence', commit, flush=True)
