export function installStartupTrafficHooks(kind) {
 'use strict';
 function _ipcStartupCounters(){return {nativeFrames:0,genericFrames:0,unclassifiedFrames:0,binaryFrames:0,binaryLogicalBytes:0,binaryBackingBytes:0,stringBodyCharacters:0,jsonFrames:0,nativeJSONFrames:0,nativeScalarStringFrames:0,genericJSONFrames:0,genericScalarStringFrames:0,nativeJSONStringCharacters:0,nativeScalarStringCharacters:0,genericJSONStringCharacters:0,genericScalarStringCharacters:0,arrayBodyFrames:0,flatPrimitiveArrayBodies:0,undefinedArraySlots:0,stringArrayCharacters:0,metadataErrors:0,methods:Object.create(null),types:Object.create(null),batchSizes:Object.create(null),channels:Object.create(null)}}
 const state=globalThis.__ipcStartupProfileStats={..._ipcStartupCounters(),diagnosticOnly:true,kind,physicalPosts:0,failedPosts:0,prototypeHooks:0,parentPortListener:false,setupErrors:[],classicIPC:{incoming:{..._ipcStartupCounters(),messages:0},outgoing:{..._ipcStartupCounters(),messages:0,failedMessages:0},incomingListener:false,outgoingHooks:0}};
 const patched=new WeakSet(),patchedContents=new WeakSet();
 const _ipcStartupIncrementCounter=(map,key)=>map[key]=(map[key]??0)+1;
 function _ipcStartupRecordFrame(message,target){
  if(ArrayBuffer.isView(message)){target.binaryFrames++;target.binaryLogicalBytes+=message.byteLength;target.binaryBackingBytes+=message.buffer.byteLength;return}
  if(!message||typeof message!=='object'){target.unclassifiedFrames++;return}
  const header=message.header;
  if(typeof message.body==='string')target.stringBodyCharacters+=message.body.length;
  if(message.jsonBody===true)target.jsonFrames++;
  if(Array.isArray(message.body)){target.arrayBodyFrames++;if(message.body.length<=8){let flat=true;for(const value of message.body){if(typeof value==='string')target.stringArrayCharacters+=value.length;if(value===undefined)target.undefinedArraySlots++;const type=typeof value;if(value!==null&&type!=='string'&&type!=='number'&&type!=='boolean'&&type!=='undefined')flat=false}if(flat)target.flatPrimitiveArrayBodies++}}
  if(typeof header==='number'){
   target.nativeFrames++;const type=header%32;_ipcStartupIncrementCounter(target.types,String(type));
   if(typeof message.body==='string'){if(type===1||type===2||type===9||type===13){target.nativeJSONFrames++;target.nativeJSONStringCharacters+=message.body.length}else if(type===14||type===15||type===16){target.nativeScalarStringFrames++;target.nativeScalarStringCharacters+=message.body.length}}
   if(typeof message.method==='string')_ipcStartupIncrementCounter(target.methods,String(message.rpcId)+':'+message.method);
  }else if(Array.isArray(header)){target.genericFrames++;if(message.jsonBody===true){target.genericJSONFrames++;if(typeof message.body==='string')target.genericJSONStringCharacters+=message.body.length}else if(typeof message.body==='string'){target.genericScalarStringFrames++;target.genericScalarStringCharacters+=message.body.length}if(header.length===4&&typeof header[0]==='number'&&typeof header[2]==='string'&&typeof header[3]==='string')_ipcStartupIncrementCounter(target.channels,header[2]+':'+header[3])}else target.unclassifiedFrames++;
 }
 function _ipcStartupRecordPacket(message,target,rawView){
  try{if(rawView){_ipcStartupIncrementCounter(target.batchSizes,'1');target.binaryFrames++;target.binaryLogicalBytes+=rawView.logical;target.binaryBackingBytes+=rawView.backing}else if(Array.isArray(message)){_ipcStartupIncrementCounter(target.batchSizes,String(message.length));for(const item of message)_ipcStartupRecordFrame(item,target)}else{_ipcStartupIncrementCounter(target.batchSizes,'1');_ipcStartupRecordFrame(message,target)}}catch{target.metadataErrors++}
 }
 function _ipcStartupPatchPort(port){
  const prototype=Object.getPrototypeOf(port);const owner=typeof prototype?.postMessage==='function'?prototype:port;
  if(patched.has(owner))return;
  const original=owner.postMessage;if(typeof original!=='function')throw new Error('MessagePort postMessage is unavailable');
  const replacement=function _ipcStartupPostMessage(message,...transfer){
   const rawView=ArrayBuffer.isView(message)?{logical:message.byteLength,backing:message.buffer.byteLength}:undefined;
   let result;try{result=Reflect.apply(original,this,[message,...transfer])}catch(error){state.failedPosts++;throw error}
   state.physicalPosts++;_ipcStartupRecordPacket(message,state,rawView);return result;
  };
  owner.postMessage=replacement;if(owner.postMessage!==replacement)throw new Error('MessagePort postMessage hook was rejected');patched.add(owner);state.prototypeHooks++;
 }
 function _ipcStartupPatchContents(contents){
  if(patchedContents.has(contents))return;const original=contents.send;if(typeof original!=='function')throw new Error('WebContents send is unavailable');
  const replacement=function _ipcStartupWebContentsSend(channel,...args){let result;try{result=Reflect.apply(original,this,[channel,...args])}catch(error){if(channel==='vscode:message')state.classicIPC.outgoing.failedMessages++;throw error}if(channel==='vscode:message'){state.classicIPC.outgoing.messages++;_ipcStartupRecordPacket(args[0],state.classicIPC.outgoing)}return result};
  Object.defineProperty(contents,'send',{value:replacement,writable:true,configurable:true,enumerable:false});if(contents.send!==replacement)throw new Error('WebContents send hook was rejected');patchedContents.add(contents);state.classicIPC.outgoingHooks++;
 }
 if(kind==='renderer'){
  if(typeof MessagePort!=='function')throw new Error('Renderer MessagePort unavailable');_ipcStartupPatchPort(Object.create(MessagePort.prototype));
 }else if(kind==='main'){
  const electron=typeof require==='function'?require('electron'):process.getBuiltinModule('module').createRequire(process.cwd()+'/package.json')('electron');
  try{const channel=new electron.MessageChannelMain();try{_ipcStartupPatchPort(channel.port1)}finally{channel.port1.close();channel.port2.close()}}catch(error){state.setupErrors.push('MessagePort: '+error.message)}
  try{electron.ipcMain.on('vscode:message',(_event,message)=>{state.classicIPC.incoming.messages++;_ipcStartupRecordPacket(message,state.classicIPC.incoming)});state.classicIPC.incomingListener=true;electron.app.on('web-contents-created',(_event,contents)=>{try{_ipcStartupPatchContents(contents)}catch(error){state.setupErrors.push('WebContents: '+error.message)}})}catch(error){state.setupErrors.push('ClassicIPC: '+error.message)}
 }else if(kind==='extension-host'){
  if(!process.parentPort?.on)throw new Error('Utility process parentPort unavailable');process.parentPort.on('message',event=>{for(const port of event.ports??[])try{_ipcStartupPatchPort(port)}catch(error){state.setupErrors.push('UtilityPort: '+error.message)}});state.parentPortListener=true;
 }else throw new Error('Unknown startup isolate');
 return {kind,prototypeHooks:state.prototypeHooks,parentPortListener:state.parentPortListener,classicIncomingListener:state.classicIPC.incomingListener,setupErrors:state.setupErrors};
}
