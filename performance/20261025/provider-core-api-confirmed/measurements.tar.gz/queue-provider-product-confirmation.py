from pathlib import Path
import os,json,hashlib,subprocess,datetime,fcntl
p=Path('/home/simon/.cache/ipc-opt-20261025');h=p/'provider-product-harness';lock=(p/'provider-product-confirmation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert 'All current packaged confirmations and startup profiles complete' in (p/'current-product-confirmation-promoted.log').read_text()
meta=json.loads((h/'experiment.json').read_text());assert hashlib.sha256((h/'product-extension/extension.cjs').read_bytes()).hexdigest()==meta['fixtureSHA256'];assert json.loads((p/'provider-product-fixture-contract-probe.json').read_text())['fixtureSHA256']==meta['fixtureSHA256']
products=json.loads((p/'products-current-core.json').read_text());mapping={'control':products['control'],'same-aa':products['control'].copy(),'fastipc':products['candidate']};assert len({len(x) for x in mapping})==1 and len('control')==7
assert mapping['control']['commit'].rsplit('@',1)[-1]=='a167347ebc4ab8923c027674f602a4f74d39ada5';assert mapping['fastipc']['commit'].rsplit('@',1)[-1]=='aac6b0fcf3bc6714c8cd7e7dd9fa1bfe6618ba25'
mapfile=p/'products-provider-current-core.json';assert not mapfile.exists();mapfile.write_text(json.dumps(mapping,indent=2)+'\n')
e=os.environ.copy();e['PATH']='/home/simon/.nvm/versions/node/v24.22.0/bin:'+e['PATH'];e.pop('GH_TOKEN',None);e.pop('GITHUB_TOKEN',None)
plans=[]
for schedule,concurrency in [('batch32',32),('sequential',1)]:
 name='product-provider-plumbing-'+schedule;cmd=['python3',str(h/'perf-product-pairs.py'),'--products',str(mapfile),'--output',str(p/name),'--variants','control,fastipc','--fixtures','hover-provider','--replicates','1','--iterations','64','--warmup','128','--concurrency',str(concurrency)];plans.append({'output':name,'command':cmd,'plumbingOnly':True})
for schedule,concurrency in [('batch32',32),('sequential',1)]:
 for kind,reps,variants in [('aa10',10,'control,same-aa'),('final50',50,'control,fastipc')]:
  name='product-provider-core-'+kind+'-'+schedule;cmd=['python3',str(h/'perf-product-pairs.py'),'--products',str(mapfile),'--output',str(p/name),'--variants',variants,'--fixtures','hover-provider','--replicates',str(reps),'--iterations','8192','--warmup','4096' if concurrency==32 else '16384','--concurrency',str(concurrency)];plans.append({'output':name,'command':cmd,'plumbingOnly':False})
(p/'provider-product-confirmation-plan.json').write_text(json.dumps({'scope':'Additional actualAPI multi-roundtrip command/hoverprovider pipeline, exacta167→AACpackages; independentAA10beforefixed50pairsforeachconcurrency32anddirectawait1. Bothpackageplumbinggatesfirst. EveryreturnedMarkdown/URI/position/tokenvalidated, exactprovider/commandcounts, setup/warmup/GCexcluded. Alllabels7charswithsameencodedURIlengthwithincomparison. No smokeSuite/UIhoverlatency/startupspeedclaim andno poolingwithotherAPIscopes. Current960processprimaryinputs/resultsunchanged. No newworker.','cases':plans},indent=2)+'\n')
completed=[]
for case in plans:
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'BEGIN',case['output'],flush=True)
 with (p/(case['output']+'.log')).open('w') as log:r=subprocess.run(case['command'],cwd=p,env=e,stdout=log,stderr=subprocess.STDOUT)
 if r.returncode:
  (p/'provider-product-confirmation-held.json').write_text(json.dumps({'state':'Private actualprovider fixture failed; preserveeveryraw/partialsampleandlogs. Noautoretry andno speedupclaim. Independentothercandidatescancontinue.','failed':case['output'],'exit':r.returncode,'completed':completed},indent=2)+'\n');print('Providerpipelineheld; inspectlogs',case['output'],flush=True);raise SystemExit(0)
 folder=p/case['output'];manifest=json.loads((folder/'manifest.json').read_text());lengths=set()
 for item in manifest['samples']:
  sample=json.loads((folder/item['path']).read_text());assert sample['measuredProviderCalls']==sample['measuredLogicalCalls'];assert sample['fixtureSHA256']==meta['fixtureSHA256'];lengths.add(len(sample['options']['outputDirectory']))
 assert len(lengths)==1,'ProviderfixtureURIlengthvariesacrosslabelswithincomparison'
 if not case['plumbingOnly']:
  with (p/(case['output']+'-supplementary.log')).open('w') as log:subprocess.run(['python3',str(p/'summarize-product-fixed-work.py'),case['output']],cwd=p,env=e,stdout=log,stderr=subprocess.STDOUT,check=True)
 completed.append(case['output']);print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'DONE',case['output'],flush=True)
(p/'provider-product-confirmation-complete.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed':completed,'unprofiledProcesses':240,'plumbingProcesses':4,'scope':'Separatecurrent-coreactualhoverproviderAPItest, notsource35metadataorprivatecodecprototype. AAcontrols/noiseandallresultsretained. No perfixtureearlystop/selection.'},indent=2)+'\n')
print('All real provider pipeline confirmations complete',flush=True)
