from pathlib import Path
import os, json, subprocess, hashlib, datetime, fcntl

p = Path('/home/simon/.cache/ipc-opt-20261025')
v = Path('/home/simon/.cache/vscode-ipc-opt-20261022')
lock = (p / 'provider-core-api-evidence-publication.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert not (p / 'provider-core-api-evidence-published.json').exists()
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        args = (proc / 'cmdline').read_bytes().split(b'\0')
    except OSError:
        continue
    assert not (args and Path(os.fsdecode(args[0])).name == 'perf' and b'stat' in args and any(str(p).encode() in a for a in args)), 'Publish in a counter-free serial stage'
manifest = json.loads((p / 'provider-core-api-confirmed-manifest.json').read_text())
def sha(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
assert sha(p / 'provider-core-api-confirmed.tar.gz') == manifest['archiveSHA256']
for item in manifest['files']:
    assert sha(p / item['path']) == item['sha256'], 'Archived input changed; preserve and review before publishing'
text = """# Current-core command/provider API comparison

This is the separate exact packaged a167→AAC command/hover-provider pipeline comparison. These are completed public API requests with real renderer/extension-host handlers, not UI hover latency or whole-product startup. Later metadata and private batching prototypes are outside this source comparison.

Each schedule has an independent ten-pair identical-package A/A control followed by fifty fixed before/after pairs. All 240 unprofiled and 4 plumbing application launches are retained. Fixed counts, returned Markdown/URI/position/token values, exact provider/command counts, archive identities and counter running coverage are verified. Startup, warmup and extension-host GC precede measurement. No outliers, failed-window replacement, early stopping or schedule pooling.

Instructions measure work, not CPU seconds; elapsed time is supplementary. Tables show paired median percentage changes and 95% intervals. User/kernel intervals are the original exploratory bootstrap; total/elapsed intervals use conservative sign/order statistics. No multiple-comparison correction. All A/A false positives and inconclusive results remain visible. This evidence establishes no 10–20% startup/full-smoke improvement.

"""
items = {'manifest.json': p / 'provider-core-api-confirmed-manifest.json', 'measurements.tar.gz': p / 'provider-core-api-confirmed.tar.gz'}
def cell(entry):
    low, high = entry['intervalPercent']
    suffix = ' (inconclusive)' if entry['inconclusive'] else ''
    return f"{entry['medianPairedChangePercent']:+.3f}% [{low:+.3f}, {high:+.3f}]{suffix}"
for kind, title in [('final50', 'Fixed fifty-pair comparisons'), ('aa10', 'Identical-package A/A controls')]:
    text += '## ' + title + '\n\n| Schedule | Fixture | User instructions | Kernel instructions | Total instructions | Elapsed |\n| --- | --- | --- | --- | --- | --- |\n'
    for case in manifest['campaigns']:
        if case['plumbingOnly'] or kind not in case['campaign']:
            continue
        root = p / case['campaign']
        primary = json.loads((root / 'summary.json').read_text())
        supplementary = json.loads((root / 'supplementary-fixed-work-summary.json').read_text())
        label = 'fastipc' if kind == 'final50' else 'same-aa'
        schedule = 'batch32' if primary['arguments']['concurrency'] == 32 else 'direct await1'
        items[case['campaign'] + '.summary.json'] = root / 'summary.json'
        items[case['campaign'] + '.supplementary.json'] = root / 'supplementary-fixed-work-summary.json'
        for fixture, row in primary['fixtures'].items():
            extra = supplementary['fixtures'][fixture]['metrics']
            values = [row['instructions:u']['comparisons'][label], row['instructions:k']['comparisons'][label], extra['userPlusKernelInstructionsPerCompletedCall']['comparisons'][label], extra['elapsedMs']['comparisons'][label]]
            text += '| ' + ' | '.join([schedule, fixture, *map(cell, values)]) + ' |\n'
    text += '\n'
text += "Only the original queue parent was held after all 100 measured children of the batched fifty-pair phase completed normally. The sequential A/A and fifty-pair stages resumed unchanged. No measured child was signalled, paused or repeated. Journals and source-work release are archived. The archive includes every raw result, counter CSV and process/controller log, summaries, fixture/collector source and package metadata. Named Chromium caches are not measurement evidence and are excluded.\n\n"
text += 'Archive SHA-256: `' + manifest['archiveSHA256'] + '`.\n'
readme = p / 'provider-core-api-evidence-readme.md'
readme.write_text(text)
items['README.md'] = readme
branch = 'perf/ipc-evidence-20261025'
folder = 'performance/20261025/provider-core-api-confirmed'
e = os.environ.copy()
e.pop('GH_TOKEN', None)
e.pop('GITHUB_TOKEN', None)
parent = subprocess.check_output(['git', 'rev-parse', 'refs/heads/' + branch], cwd=v, text=True).strip()
assert not subprocess.check_output(['git', 'ls-tree', parent, folder], cwd=v, text=True).strip(), 'Append-only destination exists'
attributes = subprocess.check_output(['git', 'check-attr', 'filter', '--', *[folder + '/' + name for name in items]], cwd=v, text=True)
assert ': lfs' not in attributes, 'Do not skip an actual LFS upload'
index = p / 'provider-core-api-evidence.index'
assert not index.exists(), 'Preserve interrupted publication index; reconcile before retry'
e['GIT_INDEX_FILE'] = str(index)
subprocess.run(['git', 'read-tree', parent], cwd=v, env=e, check=True)
for name, file in items.items():
    blob = subprocess.check_output(['git', 'hash-object', '-w', '--stdin'], cwd=v, input=file.read_bytes()).decode().strip()
    subprocess.run(['git', 'update-index', '--add', '--cacheinfo', '100644', blob, folder + '/' + name], cwd=v, env=e, check=True)
tree = subprocess.check_output(['git', 'write-tree'], cwd=v, env=e, text=True).strip()
commit = subprocess.check_output(['git', 'commit-tree', tree, '-p', parent], cwd=v, env=e, input='Archive complete current-core provider API comparisons and controls\n', text=True).strip()
changes = subprocess.check_output(['git', 'diff-tree', '--no-commit-id', '--name-only', '-r', commit], cwd=v, text=True).splitlines()
assert len(changes) == len(items) and all(path.startswith(folder + '/') for path in changes)
e.pop('GIT_INDEX_FILE')
e['GH_TOKEN'] = subprocess.check_output(['gh', 'auth', 'token', '--user', 'SimonSiefke'], text=True).strip()
e['GIT_LFS_SKIP_PUSH'] = '1'
git = ['git', '-c', 'credential.helper=', '-c', 'credential.helper=!gh auth git-credential']
remote = subprocess.check_output(git + ['ls-remote', 'https://github.com/SimonSiefke/vscode.git', 'refs/heads/' + branch], cwd=v, env=e, text=True).split()[0]
assert remote == parent, 'Remote evidence advanced; preserve prepared commit/index and reconcile'
subprocess.run(['git', 'update-ref', 'refs/heads/' + branch, commit, parent], cwd=v, check=True)
subprocess.run(git + ['push', 'https://github.com/SimonSiefke/vscode.git', 'refs/heads/' + branch + ':refs/heads/' + branch], cwd=v, env=e, check=True)
status = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commit': commit, 'parent': parent, 'folder': folder, 'archiveSHA256': manifest['archiveSHA256'], 'counts': manifest['counts'], 'action': 'Append-only existing evidence branch publication; no PR operation or feature worktree mutation'}
(p / 'provider-core-api-evidence-published.json').write_text(json.dumps(status, indent=2) + '\n')
progress_file = p / 'progress-current.json'
progress = json.loads(progress_file.read_text())
progress['evidenceHead'] = commit
progress['providerCoreAPIEvidence'] = status
progress_file.write_text(json.dumps(progress, indent=2) + '\n')
print('Published complete current-core API evidence', commit, flush=True)
