from pathlib import Path
import os, json, hashlib, tarfile, subprocess, datetime, fcntl

p = Path('/home/simon/.cache/ipc-opt-20261025')
lock = (p / 'provider-core-api-evidence-preparation.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
assert 'All current packaged confirmations and startup profiles complete' in (p / 'current-product-confirmation-promoted.log').read_text()
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        args = (proc / 'cmdline').read_bytes().split(b'\0')
    except OSError:
        continue
    assert not (args and Path(os.fsdecode(args[0])).name == 'perf' and b'stat' in args and any(str(p).encode() in a for a in args)), 'Wait for a counter-free serial stage'
archive = p / 'provider-core-api-confirmed.tar.gz'
assert not archive.exists(), 'Preserve completed or interrupted archives; do not automatically repeat'
assert json.loads((p / 'provider-product-confirmation-complete.json').read_text())['unprofiledProcesses'] == 240
harness = p / 'provider-product-harness'
fixture_sha = hashlib.sha256((harness / 'product-extension/extension.cjs').read_bytes()).hexdigest()
assert fixture_sha == json.loads((p / 'provider-product-fixture-contract-probe.json').read_text())['fixtureSHA256']
assert fixture_sha == json.loads((harness / 'experiment.json').read_text())['fixtureSHA256']
plan = json.loads((p / 'provider-product-confirmation-plan.json').read_text())
products = json.loads((p / 'products-provider-current-core.json').read_text())
assert products['control']['commit'].endswith('@a167347ebc4ab8923c027674f602a4f74d39ada5')
assert products['fastipc']['commit'].endswith('@aac6b0fcf3bc6714c8cd7e7dd9fa1bfe6618ba25')
assert products['same-aa'] == products['control']
files, campaigns, counts = [], [], {'unprofiled': 0, 'plumbing': 0, 'rawProfiles': 0}
for case in plan['cases']:
    root = p / case['output']
    command = case['command']
    arg = lambda name: command[command.index('--' + name) + 1]
    expected = int(arg('replicates')) * len(arg('variants').split(',')) * len(arg('fixtures').split(','))
    summary = json.loads((root / 'summary.json').read_text())
    manifest = json.loads((root / 'manifest.json').read_text())
    assert summary['diagnosticOnly'] is False
    for name in ['replicates', 'iterations', 'warmup', 'concurrency']:
        assert summary['arguments'][name] == int(arg(name))
    assert summary['arguments']['variants'] == arg('variants') and summary['arguments']['fixtures'] == arg('fixtures')
    results = sorted(root.glob('*/result.json'))
    assert len(results) == expected and len(manifest['samples']) == expected
    assert {str(f.relative_to(root)) for f in results} == {r['path'] for r in manifest['samples']}
    assert all(r['status'] == 'success' for r in manifest['samples'])
    runtimes = set()
    for result in results:
        row = json.loads(result.read_text())
        assert row['measuredLogicalCalls'] == int(arg('iterations')) and row['fixtureSHA256'] == fixture_sha
        assert row['product'] == products[row['variant']]
        assert row['options']['fixture'] == 'hover-provider' and row['measuredProviderCalls'] == row['measuredLogicalCalls']
        assert row['executableSHA256'] == products[row['variant']]['executableSHA256']
        assert row['bufferPool'] == 8192 and not (result.parent / 'error.json').exists()
        assert set(row['counters']) == {'instructions:u', 'instructions:k'}
        assert all(value['count'] > 0 and float(value['raw'][4]) >= 99 for value in row['counters'].values())
        runtimes.add((row['node'], row['vscodeVersion']))
        files.extend(result.parent / name for name in ['result.json', 'counts.csv', 'process.log'])
    assert len(runtimes) == 1, 'Keep runtime scopes separate'
    plumbing = case.get('plumbingOnly', False)
    if not plumbing and not (root / 'supplementary-fixed-work-summary.json').exists():
        with (p / (case['output'] + '-archive-supplementary.log')).open('w') as out:
            subprocess.run(['python3', str(p / 'summarize-product-fixed-work.py'), case['output']], cwd=p, stdout=out, stderr=out, check=True)
    files.extend([root / 'manifest.json', root / 'summary.json', p / (case['output'] + '.log')])
    if not plumbing:
        files.append(root / 'supplementary-fixed-work-summary.json')
    counts['plumbing' if plumbing else 'unprofiled'] += expected
    campaigns.append({'campaign': case['output'], 'processes': expected, 'plumbingOnly': plumbing, 'arguments': summary['arguments'], 'observedRuntime': [{'node': a, 'vscodeVersion': b} for a, b in runtimes]})
assert counts['unprofiled'] == 240 and counts['plumbing'] == 4
assert json.loads((p / 'provider-product-confirmation-complete.json').read_text())['unprofiledProcesses'] == 240
for name in ['products-provider-current-core.json', 'provider-product-confirmation-plan.json', 'queue-provider-product-confirmation.py', 'provider-product-confirmation-controller.log', 'provider-product-confirmation-complete.json', 'provider-product-fixture-contract-probe.json', 'summarize-product-fixed-work.py', 'prepare-provider-core-api-evidence.py', 'publish-provider-core-api-evidence.py', 'context-typefix-gap.json', 'context-typefix-gap-release.json']:
    files.append(p / name)
for file in harness.rglob('*'):
    if file.is_file() and not file.is_symlink() and file.suffix in ['.py', '.mjs', '.cjs', '.json', '.html'] and '__pycache__' not in file.parts:
        files.append(file)
for variant in ['control', 'fastipc']:
    directory = Path(products[variant]['executable']).parent.parent
    metadata = json.loads((directory / 'build.json').read_text())
    assert metadata['commit'] == products[variant]['commit'] and metadata['archiveSha256'] == products[variant]['archiveSha256']
    files.append(directory / 'build.json')
def sha(file):
    with file.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
files = sorted(set(files))
assert all(f.is_file() and not f.is_symlink() and f.resolve().is_relative_to(p) for f in files)
with tarfile.open(archive, 'w:gz', compresslevel=3) as tar:
    for file in files:
        tar.add(file, arcname=str(file.relative_to(p)), recursive=False)
record = {'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'Separate exact a167 to AAC actual public command/hover-provider pipeline. Independent A/A10 then fixed50 pairs in batch32/directawait1. All240 unprofiled plus4plumbing launches. Returned Markdown,URI,position,token and exact command/provider completion counts validated by fixture. Not UI hover latency or startup/full-smoke speedup. Later metadata/private candidates outside comparison. No pooling/filtering/selective reruns.', 'counts': counts, 'products': products, 'fixtureSHA256': fixture_sha, 'campaigns': campaigns, 'archiveBytes': archive.stat().st_size, 'archiveSHA256': sha(archive), 'provenanceNote': 'Only original queue parent held after complete100process batch50 provider phase. All100measured children finished normally; no child signalled/paused/repeated. Original sequential AA10/fixed50 resumed unchanged. Journal and exact source-work release retained.', 'files': [{'path': str(f.relative_to(p)), 'bytes': f.stat().st_size, 'sha256': sha(f)} for f in files]}
(p / 'provider-core-api-confirmed-manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print('Prepared complete current-core API evidence:', counts, len(files), 'files', record['archiveBytes'], 'archive bytes', flush=True)
