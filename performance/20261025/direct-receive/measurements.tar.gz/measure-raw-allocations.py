from pathlib import Path
import json,os,subprocess,statistics,shutil,hashlib
p=Path('/home/simon/.cache/ipc-opt-20261025');d=Path('/home/simon/.cache/ipc-performance-driver-20261025/scripts/ipc-benchmark');node='/home/simon/.nvm/versions/node/v24.22.0/bin/node';maps=json.loads((p/'raw-selected-runtimes.json').read_text());output=p/'raw-selected-allocations';output.mkdir()
for replicate in range(4):
 for fixture in ['primitive','small-object']:
  for variant in (['control','raw-receive'] if replicate%2==0 else ['raw-receive','control']):
   options={**maps[variant],'fixture':fixture,'iterations':10000};target=output/f'{replicate}-{fixture}-{variant}.json';env={**os.environ,'IPC_OPT_BENCH_OPTIONS':json.dumps(options),'OUTPUT':str(target)}
   with target.with_suffix('.log').open('w') as log:subprocess.run([node,'--import',str(d/'product-pool.mjs'),str(d/'allocations.mjs')],env=env,stdout=log,stderr=log,check=True)
   print('Collected',replicate,fixture,variant,flush=True)
rows=[]
for fixture in ['primitive','small-object']:
 values={v:[json.loads((output/f'{r}-{fixture}-{v}.json').read_text()) for r in range(4)] for v in maps}
 medians={v:statistics.median(x['sampledBytesPerCall'] for x in xs) for v,xs in values.items()};rows.append({'fixture':fixture,'independentProcessesPerVariant':4,'callsPerProcess':10000,'medianEstimatedBytesPerLogicalCall':medians,'changePercent':(medians['raw-receive']/medians['control']-1)*100,'diagnosticOnly':True})
(output/'summary.json').write_text(json.dumps(rows,indent=2));shutil.copy2(d/'allocations.mjs',output/'allocations.mjs');print(json.dumps(rows,indent=2),flush=True)
# Separate diagnostic runtimes: counter instrumentation is never used for CPU or byte sampling.
for variant,runtime in maps.items():
 tracked=p/('tracked-buffer-'+variant);shutil.copytree(runtime['root'],tracked,symlinks=True);file=tracked/'out/vs/base/common/buffer.js';source=file.read_text();needle='  constructor(buffer) {\n';assert source.count(needle)==1;source=source.replace(needle,needle+'    globalThis.__ipcVSBufferConstructions = (globalThis.__ipcVSBufferConstructions || 0) + 1;\n');file.write_text(source)
 (tracked/'instrumentation.json').write_text(json.dumps({'purpose':'Exact constructor diagnostic only; never use for primary perf or sampled byte comparisons','instrumentedModule':'out/vs/base/common/buffer.js','sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'counter':'__ipcVSBufferConstructions'},indent=2))
print('Prepared separately instrumented constructor-count runtimes.',flush=True)
