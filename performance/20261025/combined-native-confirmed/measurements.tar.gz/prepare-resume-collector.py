from pathlib import Path
import json,hashlib
p=Path('/home/simon/.cache/ipc-opt-20261025');h=p/'native-promise-harness';manifest=json.loads((h/'experiment.json').read_text())
for name,expected in manifest['scripts'].items():assert hashlib.sha256((h/name).read_bytes()).hexdigest()==expected,name
for name in ['perf-pairs.py','perf-electron-pairs.py']:
 s=(h/name).read_text();s=s.replace('import subprocess\n','import subprocess\nimport shutil\nimport datetime\n')
 needle="parser.add_argument('--root', required=True)";assert s.count(needle)==1;s=s.replace(needle,"parser.add_argument('--resume', action='store_true')\n"+needle)
 s=s.replace('output.mkdir(parents=True, exist_ok=False)','output.mkdir(parents=True, exist_ok=args.resume)')
 needle='            target.mkdir()';assert s.count(needle)==1
 s=s.replace(needle,'''            if args.resume and (target / 'result.json').exists():
                previous = json.loads((target / 'result.json').read_text())
                runtime = runtimes.get(variant, {})
                runtime_root = Path(runtime.get('root', str(root)))
                module = runtime.get('module', 'vs/workbench/services/extensions/common/rpcProtocol.' + variant + '.js')
                expected = {'root': str(runtime_root), 'module': module, 'fixture': fixture, 'iterations': args.iterations, 'warmup': args.warmup, 'concurrency': args.concurrency, 'handler': args.handler}
                if variant in args.port_variants.split(','):
                    expected['portModule'] = 'vs/workbench/services/extensions/common/rpcMessagePort.cached-wrap.js'
                assert previous['options'] == expected, ('Changed sample inputs', label)
                assert previous['measuredLogicalCalls'] == args.iterations, label
                if 'counters' in previous and 'compiledSHA256' in previous and 'portSHA256' in previous:
                    assert previous['replicate'] == replicate and previous['variant'] == variant, label
                    assert previous['compiledSHA256'] == hashlib.sha256((runtime_root / 'out' / module).read_bytes()).hexdigest(), label
                    assert previous['portSHA256'] == hashlib.sha256((runtime_root / 'out' / expected.get('portModule', 'vs/workbench/services/extensions/common/rpcMessagePort.js')).read_bytes()).hexdigest(), label
                    rows = {}
                    for row in csv.reader((target / 'counts.csv').read_text().splitlines(), delimiter=';'):
                        if len(row) >= 3 and row[2] in ['instructions:u', 'instructions:k']:
                            assert float(row[0]) > 0 and (not row[4].strip() or float(row[4]) >= 99), (label, row)
                            rows[row[2]] = row
                    assert set(rows) == {'instructions:u', 'instructions:k'}, label
                    for counter, row in rows.items():
                        assert previous['counters'][counter]['count'] == float(row[0]), label
                        assert previous['counters'][counter]['perLogicalCall'] == float(row[0]) / args.iterations, label
                    manifest['samples'].append({'label': label, 'status': 'success', 'path': label + '/result.json', 'preservedFromBeforeMigration': True})
                    print('Preserved', label, flush=True)
                    continue
            if target.exists():
                assert args.resume, target
                archive = output / 'interrupted-attempts'
                archive.mkdir(exist_ok=True)
                destination = archive / (label + '-before-migration')
                assert not destination.exists(), destination
                shutil.move(str(target), str(destination))
                (destination / 'migration-note.json').write_text(json.dumps({'reason': 'Old extension app-server migration terminated the owning processes; this attempt lacks fully validated completed collector output. Original files are retained; FIFOs must not be read by artifact uploaders.', 'resumedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat()}, indent=2))
                print('Retained interrupted attempt', str(destination), flush=True)
            target.mkdir()''')
 dest=h/name.replace('.py','-resume.py');assert not dest.exists();dest.write_text(s)
(p/'resume-collector-provenance.json').write_text(json.dumps({'reason':'User-requested foreground-to-detached tmux migration killed controllers/children. Original collectors and measured child harness scripts remain byte-identical. Resume-only collector copies skip fully annotated samples after validating options, count, core/port hashes and raw counters. Incomplete attempts are retained separately and restarted. Subsequent fresh campaigns use original collectors.','originalManifest':'native-promise-harness/experiment.json','resumeCollectors':{name:hashlib.sha256((h/name).read_bytes()).hexdigest()for name in ['perf-pairs-resume.py','perf-electron-pairs-resume.py']}},indent=2))
print('Prepared validated resume collectors alongside unchanged original measured harness')
