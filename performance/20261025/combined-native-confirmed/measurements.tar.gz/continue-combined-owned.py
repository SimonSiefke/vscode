from pathlib import Path
import json,subprocess,os,datetime
p=Path('/home/simon/.cache/ipc-opt-20261025');e=os.environ.copy();e['PATH']='/home/simon/.nvm/versions/node/v24.22.0/bin:'+e['PATH'];plan=json.loads((p/'combined-owned-confirmation-plan.json').read_text())
print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'MIGRATION RESUME; preserve completed samples and retained incomplete attempts',flush=True)
for case in plan['cases']:
 output=Path(case['output'])
 if (output/'summary.json').exists():
  summary=json.loads((output/'summary.json').read_text());expected=int(case['command'][case['command'].index('--replicates')+1])*len(case['command'][case['command'].index('--fixtures')+1].split(','))*len(case['command'][case['command'].index('--variants')+1].split(','));assert len(list(output.glob('*/result.json')))==expected
  print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'PRESERVED COMPLETE',output,expected,flush=True);continue
 cmd=case['command'].copy();resuming=output.exists()
 if resuming:cmd[1]=cmd[1].replace('.py','-resume.py');cmd.append('--resume')
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'RESUME'if resuming else'BEGIN',output,flush=True)
 log=Path(str(output)+('.resume.log'if resuming else'.log'))
 with log.open('a'if resuming else'w')as f:subprocess.run(cmd,cwd=p,env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'DONE',output,flush=True)
print('All confirmations complete',flush=True)
