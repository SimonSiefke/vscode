import assert from 'node:assert/strict';
import {MessageChannel}from'node:worker_threads';
import{createHook}from'node:async_hooks';
import{readFileSync,writeFileSync}from'node:fs';
const p='/home/simon/.cache/ipc-opt-20261025',maps=JSON.parse(readFileSync(p+'/promise-initialization-runtimes.json')),results=[];
for(const[variant,entry]of Object.entries(maps)){
 const load=path=>import('file://'+entry.root+'/out/'+path);
 const[{RPCProtocol},{RPCMessagePort},{ProxyIdentifier},{errorHandler,setUnexpectedErrorHandler}]=await Promise.all([load(entry.module),load('vs/workbench/services/extensions/common/rpcMessagePort.js'),load('vs/workbench/services/extensions/common/proxyIdentifier.js'),load('vs/base/common/errors.js')]);
 const pair=new MessageChannel(),adapters=[pair.port1,pair.port2].map(port=>{const a=new RPCMessagePort(data=>port.postMessage(data));port.on('message',data=>a.acceptMessage(data));port.start();return a;});const[client,server]=adapters.map(a=>new RPCProtocol(a));const id=new ProxyIdentifier('void-notification',['$notify'],['$state']);let calls=0,mode='sync',getterCalls=0;const unexpected=[],unhandled=[];const previous=errorHandler.getUnexpectedErrorHandler(),onUnhandled=error=>unhandled.push(error);setUnexpectedErrorHandler(error=>unexpected.push(error));process.on('unhandledRejection',onUnhandled);
 server.set(id,{$notify:value=>{assert.equal(value,42);calls++;if(mode==='sync')return;if(mode==='resolved')return Promise.resolve();if(mode==='reject')return Promise.reject(new Error('async-notification'));if(mode==='throw')throw new Error('sync-notification');if(mode==='getter')return Object.defineProperty({},'then',{get(){getterCalls++;throw new Error('then-getter');}});},$state:()=>calls});const proxy=client.getProxy(id);
 try{
  await proxy.$state();
  for(const next of ['sync','resolved','reject','throw','getter']){
   mode=next;assert(proxy.$notify(42)instanceof Promise);await proxy.$state();await new Promise(setImmediate);
  }
  assert.deepEqual(unexpected.map(e=>e.message),['async-notification','sync-notification','then-getter']);assert.equal(getterCalls,1);assert.equal(unhandled.length,0);
  const counts={};
  for(const next of ['sync','resolved']){
   mode=next;for(let i=0;i<128;i++)proxy.$notify(42);await proxy.$state();await new Promise(setImmediate);
   let promiseInitializations=0;const hook=createHook({init(_id,type){if(type==='PROMISE')promiseInitializations++;}});hook.enable();
   try{
    for(let i=0;i<1024;i+=32){for(let j=0;j<32;j++)proxy.$notify(42);await proxy.$state();}
    await new Promise(setImmediate);
   }finally{hook.disable();}
   counts[next]=promiseInitializations;
  }
  results.push({variant,errorsAndSingleThenGetter:true,unhandledRejections:unhandled.length,counts,scope:'Diagnostic async_hooks Promise initializations in one process containing both peers, including 32 barriers per 1024 notifications; instrumentation changes optimization and is never used for CPU/timing measures.'});
 }finally{setUnexpectedErrorHandler(previous);process.removeListener('unhandledRejection',onUnhandled);client.dispose();server.dispose();adapters.forEach(a=>a.dispose());pair.port1.close();pair.port2.close();}
}
const control=results.find(r=>r.variant==='control');for(const candidate of results.filter(r=>r.variant!=='control')){assert.equal(control.counts.sync-candidate.counts.sync,64);assert.equal(control.counts.resolved-candidate.counts.resolved,64);}writeFileSync(p+'/promise-initialization-probes.json',JSON.stringify({diagnosticOnly:true,notificationCount:1024,observedBarrierRequests:32,fewerPromiseInitializationsPerObservedRPC:2,results},null,2));console.log(results.map(r=>({variant:r.variant,counts:r.counts,errorsPass:r.errorsAndSingleThenGetter})));
