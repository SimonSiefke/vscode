
const { createRequire } = require('node:module');
const { writeFileSync } = require('node:fs');
const { join } = require('node:path');
const root = process.argv[2], report = process.argv[3];
const load = createRequire(join(root, 'test/index.js'));
const Mocha = load('mocha');
const mocha = new Mocha({ timeout: 120000, retries: 0, reporter: 'spec', failZero: true });
mocha.addFile(join(root, 'out/main.js'));
mocha.loadFiles();

const { Chat } = load(join(root, '../automation/out/index.js'));
const { MOCK_CONFIG_MODEL_DEFAULT_SECTIONS: defaults } = load(join(root, 'out/utils.js'));
const effortHeaders = ['Thinking Effort', 'Effort Level'];
const expectedEffort = defaults?.find(section => effortHeaders.includes(section.header))?.header;
if (expectedEffort && Chat?.prototype.getModelConfigSections) {
  const getSections = Chat.prototype.getModelConfigSections;
  Chat.prototype.getModelConfigSections = async function (...args) {
    const sections = await getSections.apply(this, args);
    return sections.map(section => {
      if (!effortHeaders.includes(section.header) || section.header === expectedEffort) return section;
      console.log('[smoke-compatibility] model effort header: ' + JSON.stringify(section.header) + ' -> ' + JSON.stringify(expectedEffort));
      return { ...section, header: expectedEffort };
    });
  };
}

const tests = []; let pending = 0, retried = false;
const runner = mocha.run(failures => {
  writeFileSync(report, JSON.stringify({ tests: tests.sort(), pending, failures, retried }));
  process.exit(failures || retried || !tests.length ? 1 : 0);
});
runner.on('pass', test => tests.push(test.fullTitle()));
runner.on('pending', () => pending++);
runner.on('retry', () => { retried = true; });
