from pathlib import Path
import json,statistics,math,random
p=Path('/home/simon/.cache/ipc-opt-20261025');out={'role':'Supplementary actual elapsed time and whole-Node-process CPU time, not replacements for primary retired user instructions; same fifty independent balanced pairs. No profiler.','fixtures':{}}
for kind,fixtures in [('ordinary',['primitive','small-object','settings-100']),('strings',['text-4KiB','text-64KiB','text-escaped'])]:
 for fixture in fixtures:
  rows={v:[json.loads((p/f'scalar-final50-node-{kind}'/f'{i:03}-{fixture}-{v}'/'result.json').read_text())for i in range(50)]for v in ['control','scalar-replies']};out['fixtures'][fixture]={}
  for metric in ['elapsedMs','processCpuTotalMicroseconds']:
   values={v:[row['elapsedMs']if metric=='elapsedMs'else sum(row['processCpuMicroseconds'].values())for row in data]for v,data in rows.items()}
   ratios=[math.log(a/b)for a,b in zip(values['scalar-replies'],values['control'])];rng=random.Random(3212536);boot=sorted(statistics.median(rng.choices(ratios,k=50))for _ in range(10000));interval=[math.expm1(boot[i])*100 for i in [249,9749]]
   out['fixtures'][fixture][metric]={'median':{v:statistics.median(x)for v,x in values.items()},'medianPairedChangePercent':math.expm1(statistics.median(ratios))*100,'intervalPercent':interval,'inconclusive':interval[0]<=0<=interval[1]}
(p/'scalar-node-timing-summary.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
