import fs from 'node:fs';
import assert from 'node:assert/strict';
import {comparePairs} from '/home/simon/.cache/ipc-performance-driver-20261025/packages/large-benchmark/src/parts/Statistics/Statistics.ts';
const p='/home/simon/.cache/ipc-opt-20261025';
const r=JSON.parse(fs.readFileSync(p+'/software-startup-resource10-results/large-result-pair-1-1/result.json'));
assert.equal(r.samples.length,20);assert(r.samples.every(s=>s.status==='success'&&s.diagnostics.length===0));
const metrics={};
for(const name of [...new Set(r.samples.flatMap(s=>s.metrics.map(m=>m.name)))]){
 const before=[],after=[];
 for(let pair=0;pair<10;pair++)for(const[revision,values]of[['before',before],['after',after]]){
  const sample=r.samples.find(s=>s.pair===pair&&s.revision===revision);assert(sample);
  const metric=sample.metrics.find(m=>m.name===name);assert(metric);values.push(metric.value);
 }
 const metric=r.samples[0].metrics.find(m=>m.name===name);
 metrics[name]={unit:metric.unit,...comparePairs(before,after,metric.unit==='ms'?'median':'mean')};
}
const summary={commits:r.commits,benchmark:r.benchmark,allSamplesSuccessful:true,hardwareCountersRequired:false,pairs:10,metrics};
fs.writeFileSync(p+'/software-startup-resource10-summary.json',JSON.stringify(summary,null,2));
console.log({taskClock:metrics['task-clock'],peakPss:metrics['peakPss']});
