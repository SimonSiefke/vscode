from pathlib import Path
import json,math,statistics,random
p=Path('/home/simon/.cache/ipc-opt-20261025');out={'role':'Supplementary elapsed time and summed user/kernel instructions; renderer and utility topology, fifty independent paired processes per fixture. No profiling.','fixtures':{}}
for kind,fixtures in [('ordinary',['primitive','small-object','settings-100']),('strings',['text-4KiB','text-64KiB','text-escaped'])]:
 for fixture in fixtures:
  rows={v:[json.loads((p/f'scalar-final50-renderer-{kind}'/f'{i:03}-{fixture}-{v}'/'result.json').read_text())for i in range(50)]for v in ['control','scalar-replies']};out['fixtures'][fixture]={}
  for metric in ['elapsedMs','userPlusKernelInstructionsPerCall']:
   values={v:[row['elapsedMs']if metric=='elapsedMs'else sum(row['counters'][c]['perLogicalCall']for c in ['instructions:u','instructions:k'])for row in data]for v,data in rows.items()}
   ratios=[math.log(a/b)for a,b in zip(values['scalar-replies'],values['control'])];rng=random.Random(3212536);boot=sorted(statistics.median(rng.choices(ratios,k=50))for _ in range(10000));interval=[math.expm1(boot[i])*100 for i in [249,9749]]
   out['fixtures'][fixture][metric]={'median':{v:statistics.median(x)for v,x in values.items()},'medianPairedChangePercent':math.expm1(statistics.median(ratios))*100,'intervalPercent':interval,'inconclusive':interval[0]<=0<=interval[1]}
(p/'scalar-renderer-timing-summary.json').write_text(json.dumps(out,indent=2));print(json.dumps({f:x['elapsedMs']for f,x in out['fixtures'].items()},indent=2))
