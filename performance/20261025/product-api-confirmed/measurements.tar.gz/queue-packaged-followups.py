from pathlib import Path
import os,json,subprocess,time,datetime
p=Path('/home/simon/.cache/ipc-opt-20261025');d=Path('/home/simon/.cache/ipc-performance-driver-20261025');script=d/'scripts/ipc-benchmark/perf-product-pairs.py';e=os.environ.copy();e['PATH']='/home/simon/.nvm/versions/node/v24.22.0/bin:'+e['PATH'];plans=[]
def add(name,products,variants,fixtures,reps,iterations=32768,warmup=16384,profile=False):
 cmd=['python3',str(script),'--products',str(p/products),'--output',str(p/name),'--variants',variants,'--fixtures',fixtures,'--replicates',str(reps),'--iterations',str(iterations),'--warmup',str(warmup),'--concurrency','32','--settle-ms','5000']
 if profile:cmd.append('--cpu-profile')
 plans.append({'name':name,'command':cmd,'diagnosticOnly':profile})
add('product-cumulative-aa10','products-cumulative.json','control,aa-b','context-unchanged,context-changing,clipboard-64KiB',10)
add('product-cumulative-final50','products-cumulative.json','control,candidate','context-unchanged,context-changing,clipboard-64KiB',50)
add('product-scalar-clipboard-aa10','products-scalar.json','control,aa-b','clipboard-64KiB',10,8192,4096)
add('product-scalar-clipboard-final50','products-scalar.json','control,candidate','clipboard-64KiB',50,8192,4096)
add('product-cumulative-profiles2','products-cumulative.json','control,candidate','context-unchanged,context-changing,clipboard-64KiB',2,profile=True)
(p/'packaged-followup-plan.json').write_text(json.dumps({'purpose':'Cumulative packaged public-API CPU comparisons use exact original 4df and selected 37e releases; scalar clipboard compares ac92 and 37e. Identical-product A/A controls are independent campaigns. Profiling is diagnostic-only, runs last and is excluded from all unprofiled CPU comparisons. Counter collection is serialized after every combined candidate campaign. Every fixture validates completed calls and values; failed/missing samples are retained, never replaced by zero.','cases':plans},indent=2))
print('Waiting for the entire combined campaign; stop if its controller fails',flush=True)
while True:
 log=(p/'combined-owned-confirmation.log').read_text()
 if 'Traceback' in log or 'CalledProcessError' in log:raise RuntimeError('Combined campaign failed; inspect it before starting more measurements')
 if 'All confirmations complete' in log:break
 time.sleep(15)
for case in plans:
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'BEGIN',case['name'],flush=True)
 with(p/(case['name']+'.log')).open('w')as log:subprocess.run(case['command'],cwd=p,env=e,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'DONE',case['name'],flush=True)
print('All packaged followups complete',flush=True)
