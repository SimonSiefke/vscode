from pathlib import Path
import os, json, subprocess, hashlib, datetime

p = Path('/home/simon/.cache/ipc-opt-20261025')
v = Path('/home/simon/.cache/vscode-ipc-opt-20261022')
assert not (p / 'product-api-evidence-published.json').exists()
manifest = json.loads((p / 'product-api-confirmed-manifest.json').read_text())
assert manifest['unprofiledProcesses'] == 480 and manifest['profiledProcesses'] == 12
assert manifest['archiveBytes'] < 90 * 2**20, 'Review oversized evidence instead of pushing it'
assert hashlib.sha256((p / 'product-api-confirmed.tar.gz').read_bytes()).hexdigest() == manifest['archiveSHA256']
text = '''# Completed packaged public-API CPU measurements

These Linux process-tree hardware counters measure fixed completed VS Code public-API work in actual packaged applications. Startup, five-second settling, warmup and extension-host forced GC are outside the counter window. Per-call completion/value assertions are inside the measured fixture; result-file writing and final counter validation are outside it. The original-package cumulative comparison is microsoft/vscode@4df8bb183f0e984e97d8f4200c802c49061d7d3c → SimonSiefke/vscode@37e23c02fb542e78dadf80a205dbada712e60406. It precedes the later main merge, combined native core AAC and nineteen-method metadata264. This dataset does not measure those later increments.

Each candidate fixture has fifty fixed alternating independent pairs. Independent identical-build A/A campaigns have ten pairs per fixture. All 480 unprofiled processes validate completed calls, values and user/kernel hardware-counter running fractions of at least99%. No outliers, failed windows or labels are selectively replaced. Exact source, executable/archive hashes, runtime versions, harness arguments and file checksums are retained.

User and kernel instruction intervals are exploratory paired bootstrap intervals from the original collector. Supplementary total-instruction and elapsed intervals are conservative95% order-statistic intervals for median paired log-ratios from the same completed samples. There is no multiple-comparison correction. Instructions, CPU time and elapsed time are distinct; none is a full smoke-suite or startup speedup.

## Original-package cumulative comparison

'''
def comparison(value):
    lo, hi = value['intervalPercent']
    return f"{value['medianPairedChangePercent']:+.2f}% [{lo:+.2f}%, {hi:+.2f}%]" + (' (inconclusive)' if value['inconclusive'] else '')

def table(campaign, variant):
    summary = json.loads((p / campaign / 'summary.json').read_text())
    supplementary = json.loads((p / campaign / 'supplementary-fixed-work-summary.json').read_text())
    result = '| Fixture | User instructions | Kernel instructions | User + kernel instructions | Fixed-work elapsed |\n| --- | ---: | ---: | ---: | ---: |\n'
    for fixture, data in summary['fixtures'].items():
        metrics = supplementary['fixtures'][fixture]['metrics']
        cells = [comparison(data[key]['comparisons'][variant]) for key in ['instructions:u', 'instructions:k']]
        cells += [comparison(metrics[key]['comparisons'][variant]) for key in ['userPlusKernelInstructionsPerCompletedCall', 'elapsedMs']]
        result += '| ' + fixture + ' | ' + ' | '.join(cells) + ' |\n'
    return result

text += table('product-cumulative-final50', 'candidate')
text += '\nThese fixtures perform32768 measured public-API calls after16384 warmup calls, at concurrency32. Set-context fixtures await every command completion; clipboard reads validate each returned64KiB string. Counters include all inherited application processes/threads, not just RPC code.\n\n## Scalar clipboard increment\n\nThis separate ac92→37e package comparison isolates the earlier scalar-reply increment; full source IDs and executable hashes are in the manifest. It uses8192 measured clipboard reads after4096 warmup, concurrency32.\n\n'
text += table('product-scalar-clipboard-final50', 'candidate')
text += '\n## Identical-build A/A controls\n\nBoth A/A labels use the exact same package within each campaign. These are measurement-noise controls, not optimization results.\n\n### Original-package A/A\n\n'
text += table('product-cumulative-aa10', 'aa-b')
text += '\n### Scalar-baseline A/A\n\n' + table('product-scalar-clipboard-aa10', 'aa-b')
text += '''
The scalar-baseline identical-build A/A user-instruction comparison shows a small -0.177% separation (95% bootstrap interval [-0.391%, -0.095%]) despite identical executable and fixture hashes. Its kernel, total-instruction and elapsed intervals include zero. This is a retained measurement effect, not a real optimization, and warns against claims at a few tenths of a percent without further independent confirmation. No sample is filtered or replaced to remove it.

## Separate diagnostic profiles

Twelve extension-host CPU profiles capture two independent repetitions per label/fixture only after every unprofiled campaign. They are excluded from all hardware/elapsed performance estimates. This diagnostic covers the extension host, not the renderer, main process or kernel. The summary exposes idle and instrumentation-wrapper self weights (which may include native work and are not subtracted), long sampling gaps, and named IPC ancestry; absent recognizable frames do not mean absent IPC work. Sample weights are not CPU accounting, and inclusive frames overlap. Native code, inlining and asynchronous continuations limit name-based attribution. Raw profiles remain available for inspection.

The harness is versioned at [cc3acc57](https://github.com/SimonSiefke/vscode-memory-leak-finder/tree/cc3acc57df8d6bd1bee9fd0093024ffdea90d130/scripts/ipc-benchmark). The archive includes every completed result/counter/process log, command/runtime manifests, all labels, supplementary analysis source and all twelve raw diagnostic profiles. It excludes private Chromium caches and application binaries, which are identified by exact build/archive hashes. No new pull request is created for this evidence.
'''
text += '\nArchive SHA-256: `' + manifest['archiveSHA256'] + '`.\n'
text = text.replace('at least99%', 'at least 99%').replace('conservative95%', 'conservative 95%').replace('perform32768', 'perform 32768').replace('after16384', 'after 16384').replace('concurrency32', 'concurrency 32').replace('returned64KiB', 'returned 64 KiB').replace('uses8192', 'uses 8192').replace('after4096', 'after 4096')
(p / 'product-api-evidence-readme.md').write_text(text)
branch = 'perf/ipc-evidence-20261025'
parent = subprocess.check_output(['git', 'rev-parse', 'refs/heads/' + branch], cwd=v, text=True).strip()
assert parent == json.loads((p / 'combined-product-evidence-published.json').read_text())['commit']
e = os.environ.copy()
e.pop('GH_TOKEN', None)
e.pop('GITHUB_TOKEN', None)
index = p / 'product-api-evidence.index'
assert not index.exists(), 'Preserve an interrupted isolated index for review'
e['GIT_INDEX_FILE'] = str(index)
subprocess.run(['git', 'read-tree', parent], cwd=v, env=e, check=True)
items = {'README.md': 'product-api-evidence-readme.md', 'manifest.json': 'product-api-confirmed-manifest.json', 'measurements.tar.gz': 'product-api-confirmed.tar.gz', 'extension-host-profiles.summary.json': 'product-cumulative-profile-analysis.json'}
for campaign in ['product-cumulative-aa10', 'product-cumulative-final50', 'product-scalar-clipboard-aa10', 'product-scalar-clipboard-final50']:
    items[campaign + '.summary.json'] = campaign + '/summary.json'
    items[campaign + '.timing.json'] = campaign + '/supplementary-fixed-work-summary.json'
for name, relative in items.items():
    blob = subprocess.check_output(['git', 'hash-object', '-w', '--stdin'], cwd=v, input=(p / relative).read_bytes()).decode().strip()
    subprocess.run(['git', 'update-index', '--add', '--cacheinfo', '100644', blob, 'performance/20261025/product-api-confirmed/' + name], cwd=v, env=e, check=True)
tree = subprocess.check_output(['git', 'write-tree'], cwd=v, env=e, text=True).strip()
commit = subprocess.check_output(['git', 'commit-tree', tree, '-p', parent], cwd=v, env=e, input='Archive completed packaged API CPU, calibration and diagnostic profiles\n', text=True).strip()
subprocess.run(['git', 'update-ref', 'refs/heads/' + branch, commit, parent], cwd=v, check=True)
e.pop('GIT_INDEX_FILE')
e['GH_TOKEN'] = subprocess.check_output(['gh', 'auth', 'token', '--user', 'SimonSiefke'], text=True).strip()
e['GIT_LFS_SKIP_PUSH'] = '1'
subprocess.run(['git', '-c', 'credential.helper=', '-c', 'credential.helper=!gh auth git-credential', 'push', 'https://github.com/SimonSiefke/vscode.git', 'refs/heads/' + branch + ':refs/heads/' + branch], cwd=v, env=e, check=True)
published = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'commit': commit, 'folder': 'performance/20261025/product-api-confirmed', 'archiveSHA256': manifest['archiveSHA256'], 'unprofiledProcesses': 480, 'diagnosticProfiles': 12}
(p / 'product-api-evidence-published.json').write_text(json.dumps(published, indent=2) + '\n')
progress = json.loads((p / 'progress-current.json').read_text())
progress['evidenceHead'] = commit
progress['productAPIEvidence'] = published
progress['updatedUTC'] = published['utc']
(p / 'progress-current.json').write_text(json.dumps(progress, indent=2) + '\n')
print('Published completed actual-API evidence', commit, flush=True)
