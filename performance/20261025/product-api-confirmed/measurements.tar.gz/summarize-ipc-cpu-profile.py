from pathlib import Path
import sys, json, math, hashlib, collections

IPC_NAMES = {
    '_remoteCall', '_remoteNotification', '_receiveNativeMessage', '_receiveOneMessage',
    '_receiveRequest', '_receiveNotification', '_receiveReply', '_receiveReplyErr', '_receiveCancel',
    '_onDidReceiveAcknowledge', 'serializeNativeArguments', 'serializeRequestArguments',
    'serializeRequestJSONArgs', 'serializeReplyOK', 'deserializeRequestJSONArgs',
    'deserializeReplyOKJSON', 'sendStructuredClone', 'sendStructuredCloneControl',
    'sendNative', 'wrapStructuredCloneMessage', 'getStructuredCloneMessage',
    'canSerializeChannelJSON', 'trySerializeJSONBody', 'transformStructuredCloneData',
    'deserializeStructuredCloneMessage', 'requestPromise', 'sendResponse', 'sendRequest'
}

def summarize(path):
    raw = path.read_bytes()
    profile = json.loads(raw)
    nodes = {node['id']: node for node in profile['nodes']}
    assert len(nodes) == len(profile['nodes'])
    samples, deltas = profile['samples'], profile['timeDeltas']
    assert len(samples) == len(deltas) and samples, 'Missing sample timing: report unavailable, never infer zeros'
    assert all(isinstance(delta, (int, float)) and math.isfinite(delta) and delta >= 0 for delta in deltas)
    parents = {}
    for node in nodes.values():
        for child in node.get('children', []):
            assert child in nodes and child not in parents, 'Expected a profile tree'
            parents[child] = node['id']
    self_weights = collections.Counter()
    self_counts = collections.Counter()
    inclusive_weights = collections.Counter()
    named_ipc_weight = idle_weight = hook_named_weight = 0
    named_ipc_samples = 0
    for sample, delta in zip(samples, deltas):
        assert sample in nodes
        self_weights[sample] += delta
        self_counts[sample] += 1
    # Aggregate repeated leaf samples before walking each unique stack.
    for sample, delta in self_weights.items():
        stack = []
        cursor = sample
        while cursor is not None:
            assert cursor not in stack, 'Cyclic profile node parents'
            stack.append(cursor)
            cursor = parents.get(cursor)
        for node_id in stack:
            inclusive_weights[node_id] += delta
        name = nodes[sample]['callFrame']['functionName']
        if name == '(idle)':
            idle_weight += delta
        if name.startswith('_ipcStartup') or name == 'installStartupTrafficHooks':
            hook_named_weight += delta
        if any(nodes[node_id]['callFrame']['functionName'] in IPC_NAMES for node_id in stack):
            named_ipc_weight += delta
            named_ipc_samples += self_counts[sample]
    total = sum(deltas)
    def rows(weights):
        return [{
            'nodeId': node_id,
            'function': nodes[node_id]['callFrame']['functionName'],
            'url': nodes[node_id]['callFrame'].get('url', ''),
            'lineNumber': nodes[node_id]['callFrame'].get('lineNumber'),
            'columnNumber': nodes[node_id]['callFrame'].get('columnNumber'),
            'sampleWeightMs': weight / 1000,
            'percentOfRecordedSampleWeight': weight / total * 100 if total else None,
            'selfSamples': self_counts[node_id]
        } for node_id, weight in weights.most_common(40)]
    return {
        'file': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
        'samples': len(samples), 'recordedSampleWeightMs': total / 1000,
        'declaredProfileSpanMs': (profile['endTime'] - profile['startTime']) / 1000,
        'idleSampleWeightMs': idle_weight / 1000,
        'nonIdleSampleWeightMs': (total - idle_weight) / 1000,
        'hookNamedSelfSampleWeightMs': hook_named_weight / 1000,
        'samplesUnderNamedIPCFrames': named_ipc_samples,
        'sampleWeightUnderNamedIPCFramesMs': named_ipc_weight / 1000,
        'longSampleDeltas': [{'sampleIndex': i, 'deltaMs': delta / 1000} for i, delta in enumerate(deltas) if delta > 20000],
        'topSelfFrames': rows(self_weights), 'topInclusiveFrames': rows(inclusive_weights)
    }

def main():
    assert len(sys.argv) >= 3, 'Usage: summarize-ipc-cpu-profile.py OUTPUT PROFILE...'
    output = Path(sys.argv[1])
    assert not output.exists(), 'Preserve previous analysis'
    results = [summarize(Path(path)) for path in sys.argv[2:]]
    report = {
        'diagnosticOnly': True,
        'analyzerSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope': 'Weighted sampled stacks from raw V8 CPU profiles. timeDeltas are sample weights, not hardware CPU accounting or benchmark elapsed estimates. Debugger pauses, startup marker waits and hooks perturb these diagnostic launches. No outliers or long sample deltas are removed.',
        'coverage': 'Named IPC attribution is an explicit function-name heuristic, with raw URL/line/column identities retained. Missing recognizable frames do not imply zero IPC work. Inclusive rows overlap and must not be summed. Hook-named self weight is literal attribution, not an overhead correction: V8 may charge native postMessage work to its JS wrapper when native frames are not exposed. All such weight is retained; never subtract it as instrumentation overhead.',
        'namedIPCFunctions': sorted(IPC_NAMES), 'profiles': results
    }
    output.write_text(json.dumps(report, indent=2) + '\n')
    print('Summarized', len(results), 'diagnostic profiles; no performance estimate')

if __name__ == '__main__':
    main()
