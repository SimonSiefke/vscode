from pathlib import Path
import os, json, hashlib, tarfile, subprocess, datetime

p = Path('/home/simon/.cache/ipc-opt-20261025')
assert 'All packaged followups complete' in (p / 'packaged-followup-queue.log').read_text()
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        args = (proc / 'cmdline').read_bytes().split(b'\0')
    except OSError:
        continue
    assert not (args and Path(os.fsdecode(args[0])).name == 'perf' and b'stat' in args and any(str(p).encode() in arg for arg in args)), 'Wait for a counter-free gap'
archive = p / 'product-api-confirmed.tar.gz'
assert not archive.exists(), 'Preserve completed or interrupted archive attempts'
cases = {
    'product-cumulative-aa10': 60,
    'product-cumulative-final50': 300,
    'product-scalar-clipboard-aa10': 20,
    'product-scalar-clipboard-final50': 100,
    'product-cumulative-profiles2': 12
}
files, profiles, campaigns = [], [], []
fixture_sha = hashlib.sha256(Path('/home/simon/.cache/ipc-performance-driver-20261025/scripts/ipc-benchmark/product-extension/extension.cjs').read_bytes()).hexdigest()
for name, expected in cases.items():
    root = p / name
    summary = json.loads((root / 'summary.json').read_text())
    diagnostic = name.endswith('profiles2')
    assert summary['diagnosticOnly'] is diagnostic
    results = sorted(root.glob('*/result.json'))
    assert len(results) == expected
    source_products = {}
    runtime_versions = set()
    for result in results:
        row = json.loads(result.read_text())
        assert row['measuredLogicalCalls'] == summary['arguments']['iterations']
        assert row['fixtureSHA256'] == fixture_sha, 'Measured fixture changed: do not pool versions'
        assert set(row['counters']) == {'instructions:u', 'instructions:k'}
        assert all(counter['count'] > 0 and float(counter['raw'][4]) >= 99 for counter in row['counters'].values())
        for filename in ['result.json', 'counts.csv', 'process.log']:
            f = result.parent / filename
            assert f.is_file() and not f.is_symlink()
            files.append(f)
        if diagnostic:
            f = result.parent / 'extension-host.cpuprofile'
            assert f.is_file() and not f.is_symlink()
            profiles.append(f)
            files.append(f)
        runtime_versions.add((row['node'], row['vscodeVersion']))
        key = row['product']['commit']
        source_products.setdefault(key, set()).add(row['executableSHA256'])
    assert all(len(hashes) == 1 for hashes in source_products.values())
    assert len(runtime_versions) == 1, 'Keep package runtime/version scopes matched within each campaign'
    for filename in ['manifest.json', 'summary.json']:
        files.append(root / filename)
    if not diagnostic:
        files.append(root / 'supplementary-fixed-work-summary.json')
    campaigns.append({'campaign': name, 'processes': expected, 'diagnosticOnly': diagnostic, 'arguments': summary['arguments'], 'observedRuntime': [{'node': node, 'vscodeVersion': version} for node, version in sorted(runtime_versions)], 'products': {commit: sorted(hashes) for commit, hashes in source_products.items()}})
assert len(profiles) == 12
analysis = p / 'product-cumulative-profile-analysis.json'
assert not analysis.exists()
subprocess.run(['python3', str(p / 'summarize-ipc-cpu-profile.py'), str(analysis), *map(str, profiles)], check=True)
files.append(analysis)
for filename in ['summarize-ipc-cpu-profile.py', 'summarize-product-fixed-work.py', 'products-cumulative.json', 'products-scalar.json', 'packaged-followup-plan.json', 'queue-packaged-followups.py', 'prepare-product-api-evidence.py', 'publish-product-api-evidence.py']:
    files.append(p / filename)
driver = Path('/home/simon/.cache/ipc-performance-driver-20261025')
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=driver, text=True).strip() == ''
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=driver, text=True).strip() == 'cc3acc57df8d6bd1bee9fd0093024ffdea90d130'
harness_manifest = []
for f in sorted((driver / 'scripts/ipc-benchmark').rglob('*')):
    if f.suffix not in ['.py', '.mjs', '.cjs', '.json', '.html'] or not f.is_file() or f.is_symlink() or '__pycache__' in f.parts:
        continue
    harness_manifest.append({'path': str(f.relative_to(driver)), 'sha256': hashlib.sha256(f.read_bytes()).hexdigest()})
def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()
files = sorted(set(files))
assert all(f.is_file() and not f.is_symlink() for f in files)
with tarfile.open(archive, 'w:gz', compresslevel=3) as tar:
    for f in files:
        tar.add(f, arcname=str(f.relative_to(p)), recursive=False)
manifest = {
    'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Completed original4df→37e cumulative public-API comparisons and ac92→37e scalar-clipboard increment, each with independent identical-build A/A10 then fixed50 pairs. Separate12 profiled runs are diagnostic only and excluded from unprofiled statistics. These packages precede the main merge, combined core AAC and nineteen-method metadata264; no source/runtime scopes are pooled.',
    'unprofiledProcesses': 480, 'profiledProcesses': 12,
    'failedWindowsReplaced': 0, 'outliersRemoved': 0,
    'archiveBytes': archive.stat().st_size, 'archiveSHA256': sha(archive),
    'campaigns': campaigns,
    'harnessCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=driver, text=True).strip(),
    'harnessFiles': harness_manifest, 'measuredFixtureSHA256': fixture_sha,
    'files': [{'path': str(f.relative_to(p)), 'bytes': f.stat().st_size, 'sha256': sha(f)} for f in files]
}
(p / 'product-api-confirmed-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Prepared completed actual-API evidence:', len(files), 'files;', manifest['archiveBytes'], 'bytes', flush=True)
