from pathlib import Path
import os,json,math,statistics,hashlib,datetime
p=Path('/home/simon/.cache/ipc-opt-20261025')
record=json.loads((p/'proxy-factory-independent-confirmation.json').read_text());assert record['state']=='completed-independent-proxy-confirmation-await-review'
gap=json.loads((p/'proxy-factory-independent-root-review.json').read_text());assert gap['state']=='ready-counterfree-root-review' and not (p/'proxy-factory-independent-root-review-release.json').exists();assert datetime.datetime.fromisoformat(gap['deadlineUTC'])>datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=5)
for q in Path('/proc').iterdir():
 if not q.name.isdigit():continue
 try:a=(q/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 assert not(a and Path(os.fsdecode(a[0])).name=='perf' and b'stat' in a and any(str(p).encode() in x for x in a)), 'Counterfree summary only'
output=p/'proxy-factory-independent-total-timing-summary.json';assert not output.exists(),'Preserve original supplementary summary'
mapping=json.loads((p/'proxy-factory-independent-runtimes.json').read_text())
def sha(file):return hashlib.sha256(file.read_bytes()).hexdigest()
compiled={label:sha(Path(row['root'])/'out'/row['module']) for label,row in mapping.items()}
ports={label:sha(Path(row['root'])/'out/vs/workbench/services/extensions/common/rpcMessagePort.js') for label,row in mapping.items()}
out={'scope':'All completed independent proxy960processes, including allAAcontrols and all regressions; totalinstructions and elapsed from same unprofiled fixedwork. No new benchmark, exclusions, source selection or pooled cohorts. NodeprocessCPU is supplementary softwareaccounting; not hardwareinstructioncost.','intervalMethod':'Conservative95% sign/orderstatistic interval for median pairedlogratio, no multiple-comparison adjustment; user/kernel exploratory bootstrap remains in original summaries.','campaigns':{},'inputFiles':[]}
processes=0
for case in record['plans']:
 if case['plumbingOnly']:continue
 root=p/case['name'];summary=json.loads((root/'summary.json').read_text());n=summary['pairedIndependentProcesses'];assert n in [10,50];labels=summary['arguments']['variants'].split(',');assert len(labels)==2 and labels[0]=='control';label=labels[1];iterations=summary['arguments']['iterations'];assert len(list(root.glob('*/result.json')))==n*len(summary['fixtures'])*2
 tail=0;r=-1
 for i in range(n):
  tail+=math.comb(n,i)/2**n
  if tail<=.025:r=i
  else:break
 assert r>=0;rows={}
 for fixture in summary['fixtures']:
  values={}
  for variant in labels:
   samples=[]
   for i in range(n):
    file=root/f'{i:03}-{fixture}-{variant}/result.json';d=json.loads(file.read_text());assert d['measuredLogicalCalls']==iterations and d['replicate']==i and d['variant']==variant and d['preflightCalls']==1 and d['preflightNativePromise'] is True;assert d['compiledSHA256']==compiled[variant] and d['portSHA256']==ports[variant]
    assert set(d['counters'])=={'instructions:u','instructions:k'} and all(c['count']>0 and float(c['raw'][4])>=99 for c in d['counters'].values());assert d['elapsedMs']>0
    samples.append(d);out['inputFiles'].append({'path':str(file.relative_to(p)),'sha256':sha(file)})
   values[variant]=samples;processes+=n
  metrics={'elapsedMs':lambda d:d['elapsedMs'],'userPlusKernelInstructions':lambda d:sum(d['counters'][m]['count'] for m in ['instructions:u','instructions:k'])}
  if case['name'].endswith('-node'):metrics['processCpuMicroseconds']=lambda d:sum(d['processCpuMicroseconds'].values())
  rows[fixture]={}
  for name,read in metrics.items():
   before=[read(d) for d in values['control']];after=[read(d) for d in values[label]];assert all(math.isfinite(v) and v>0 for v in before+after);ratios=sorted(math.log(a/b) for a,b in zip(after,before));lo,hi=[(math.exp(ratios[i])-1)*100 for i in [r,n-1-r]]
   rows[fixture][name]={'pairs':n,'medianPairedChangePercent':(math.exp(statistics.median(ratios))-1)*100,'intervalPercent':[lo,hi],'inconclusive':lo<=0<=hi,'medianBefore':statistics.median(before),'medianAfter':statistics.median(after),'allPairsRetained':True}
  print(case['name'],fixture,{name:{k:v for k,v in x.items() if k in ['medianPairedChangePercent','intervalPercent','inconclusive']} for name,x in rows[fixture].items()},flush=True)
 out['campaigns'][case['name']]=rows
assert processes==960;out['unprofiledProcesses']=processes;output.write_text(json.dumps(out,indent=2)+'\n');print('All960processes validated and supplementary metrics retained.')
