from pathlib import Path
import os,json,hashlib,tarfile,datetime,fcntl
p=Path('/home/simon/.cache/ipc-opt-20261025');lock=(p/'proxy-factory-evidence-preparation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
gap=json.loads((p/'proxy-factory-independent-root-review.json').read_text());assert gap['state']=='ready-counterfree-root-review' and not (p/'proxy-factory-independent-root-review-release.json').exists();assert datetime.datetime.fromisoformat(gap['deadlineUTC'])>datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=5)
for q in Path('/proc').iterdir():
 if not q.name.isdigit():continue
 try:a=(q/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 assert not(a and Path(os.fsdecode(a[0])).name=='perf' and b'stat' in a and any(str(p).encode() in x for x in a)), 'Counterfree archive only'
archive=p/'proxy-factory-confirmed.tar.gz';assert not archive.exists(),'Preserve previous archive/partials'
independent=json.loads((p/'proxy-factory-independent-confirmation.json').read_text());assert independent['state']=='completed-independent-proxy-confirmation-await-review';assert json.loads((p/'proxy-factory-independent-total-timing-summary.json').read_text())['unprofiledProcesses']==960
original=json.loads((p/'proxy-method-factory-pilot-plan.json').read_text());plans=[{**c,'name':c['output'],'cohort':'original-screen'} for c in original['cases']]+[{**c,'cohort':'independent'} for c in independent['plans']]
files=set();campaigns=[];counts={}
for case in plans:
 root=p/case['name'];summary=json.loads((root/'summary.json').read_text());n=summary['pairedIndependentProcesses'];args=summary['arguments'];expected=n*len(args['variants'].split(','))*len(summary['fixtures']);results=list(root.glob('*/result.json'));assert len(results)==expected
 for file in results:
  d=json.loads(file.read_text());assert d['measuredLogicalCalls']==args['iterations'] and set(d['counters'])=={'instructions:u','instructions:k'};assert all(c['count']>0 and float(c['raw'][4])>=99 for c in d['counters'].values())
  for name in ['result.json','counts.csv','process.log']:
   f=file.parent/name;assert f.is_file();files.add(f)
 for name in ['summary.json','manifest.json']:
  f=root/name
  if f.exists():files.add(f)
 files.add(p/(case['name']+'.log'));key=case['cohort']+('-plumbing' if case.get('plumbingOnly',False) else '-unprofiled');counts[key]=counts.get(key,0)+expected;campaigns.append({'campaign':case['name'],'cohort':case['cohort'],'processes':expected,'plumbingOnly':case.get('plumbingOnly',False),'arguments':args})
assert counts['independent-unprofiled']==960 and counts['independent-plumbing']==8
allocation=p/'proxy-method-factory-allocations';profiles=list(allocation.glob('*.json'));assert len([f for f in profiles if f.name!='summary.json'])==24;files.update(f for f in allocation.iterdir() if f.is_file() and not f.is_symlink())
request=json.loads((p/'proxy-factory-independent-confirmation-request.json').read_text())
for name,digest in request['inputs'].items():
 f=p/name;assert hashlib.sha256(f.read_bytes()).hexdigest()==digest;files.add(f)
for name in ['proxy-method-factory-preparation.json','proxy-method-factory-pilot-plan.json','proxy-method-factory-runtimes.json','proxy-method-factory-semantic-probes.json','proxy-method-factory-property-probes.json','proxy-method-factory-property-probes.log','proxy-method-factory-complete-review.json','proxy-factory-independent-complete-review.json','proxy-factory-independent-total-timing-summary.json','proxy-factory-independent-total-timing-summary.log','summarize-proxy-independent-total-timing.py','proxy-factory-independent-confirmation.json','proxy-factory-independent-confirmation-request.json','proxy-factory-independent-confirmation-controller.log','queue-proxy-factory-independent-confirmation.py','proxy-factory-independent-runtimes.json','proxy-factory-recovery.json','recover-proxy-factory-once.py','proxy-method-factory-current-source-validation.json','proxy-factory-current-build.log','proxy-factory-current-tests.log','proxy-factory-current-eslint.log','proxy-factory-current-parity.js','proxy-factory-current-parity.log','proxy-factory-current-commit.log','rpcProtocol.proxy-factory-current-source.ts','prepare-proxy-factory-evidence.py','publish-proxy-factory-evidence.py','allocation-sampling-calibration/summary.json']:
 files.add(p/name)
for folder in ['numeric-control-harness','native-promise-harness']:
 for f in (p/folder).iterdir():
  if f.is_file() and f.suffix in ['.py','.mjs','.cjs','.html','.json']:files.add(f)
for name in ['combined-scalar-arguments-owned-sources/vs/workbench/services/extensions/common/rpcProtocol.ts','proxy-method-factory-sources/vs/workbench/services/extensions/common/rpcProtocol.ts']:files.add(p/name)
files=sorted(files);assert all(f.is_file() and not f.is_symlink() and f.resolve().is_relative_to(p) for f in files)
def sha(f):
 with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
with tarfile.open(archive,'w:gz',compresslevel=3) as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Two separate cohorts retained, no pooling: original52user/kernelcomparisons+24interval1JSallocationprofiles and independent960+8withAA10/fixed50. CurrentRPCsourcebeforechangebyteidenticaltomeasuredcontrol; compiledafterexactcandidatef279. Allocation-focusedsourcechange, not generalCPU/startupgain. AllAAs/kernelregressions/inconclusivevalues preserved.','counts':counts,'allocationProfiles':24,'campaigns':campaigns,'archiveBytes':archive.stat().st_size,'archiveSHA256':sha(archive),'files':[{'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':sha(f)} for f in files]};(p/'proxy-factory-confirmed-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('Prepared complete proxy evidence',counts,len(files),'files',manifest['archiveBytes'],'bytes',flush=True)
