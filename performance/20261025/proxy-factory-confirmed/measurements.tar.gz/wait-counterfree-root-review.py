from pathlib import Path
import argparse,datetime,time,json,fcntl,os
parser=argparse.ArgumentParser();parser.add_argument('--stage',required=True,choices=['proxy-factory-independent']);args=parser.parse_args()
p=Path('/home/simon/.cache/ipc-opt-20261025');stage=args.stage
lock=(p/(stage+'-root-review.lock')).open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
marker=p/(stage+'-root-review.json');release=p/(stage+'-root-review-release.json')
assert not marker.exists() and not release.exists(),'Preserve existing root review/release intent'
proof=json.loads((p/'proxy-factory-independent-confirmation.json').read_text())
assert proof['state'] in ['completed-independent-proxy-confirmation-await-review','held-preserve-all-proxy-confirmation-partials-no-automatic-repeat']
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:argv=(proc/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 assert not(argv and Path(os.fsdecode(argv[0])).name=='perf' and b'stat' in argv and any(str(p).encode() in x for x in argv)), 'No source review alongside counters'
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'ready-counterfree-root-review','pid':os.getpid(),'proofState':proof['state'],'deadlineUTC':datetime.datetime.fromtimestamp(time.time()+3600,datetime.timezone.utc).isoformat(),'scope':'Same existing serial owner after complete independent proxy experiment. No measured child paused/repeated. Up to1h for root to inspect all results, make source tradeoff and validate any authorized source/docs changes. Explicit root release or bounded lease resumes original pending-constructor queue. No user approval requested or automatic source selection.'}
marker.write_text(json.dumps(record,indent=2)+'\n');print('Counterfree independent proxy root review ready',flush=True);deadline=time.monotonic()+3600
while time.monotonic()<deadline:
 if release.exists():
  record['release']=json.loads(release.read_text());record['state']='released-original-serial-queue';break
 time.sleep(10)
else:record['state']='lease-expired-original-serial-queue-resumes'
record['resumedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat();marker.write_text(json.dumps(record,indent=2)+'\n');print(record['state'],flush=True)
