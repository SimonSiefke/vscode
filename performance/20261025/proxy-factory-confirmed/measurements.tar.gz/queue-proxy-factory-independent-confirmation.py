from pathlib import Path
import json,os,subprocess,hashlib,datetime,fcntl
p=Path('/home/simon/.cache/ipc-opt-20261025');request=p/'proxy-factory-independent-confirmation-request.json'
if not request.exists():
 print('No proxy factory confirmation requested; original queue continues',flush=True);raise SystemExit(0)
lock=(p/'proxy-factory-independent-confirmation.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
marker=p/'proxy-factory-independent-confirmation.json';assert not marker.exists(),'Preserve previous intent and all partial samples; no automatic repeat'
r=json.loads(request.read_text());assert r['state']=='independent-confirmation-requested-not-production-selection'
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==r['driverSHA256'],'Prepared driver changed before first measurement'
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:args=(proc/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 assert not(args and Path(os.fsdecode(args[0])).name=='perf' and b'stat' in args and any(str(p).encode() in x for x in args)),'Earlier owned counters active'
assert json.loads((p/'proxy-factory-recovery.json').read_text())['state']=='completed-first-actual-proxy-experiment'
for name,digest in r['inputs'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,'Frozen input changed'
original=json.loads((p/'proxy-method-factory-runtimes.json').read_text());assert set(original)=={'control','proxy-method-factory'}
mapping={**original,'same-aa':original['control'].copy()};mapfile=p/'proxy-factory-independent-runtimes.json';assert not mapfile.exists();mapfile.write_text(json.dumps(mapping,indent=2)+'\n')
e=os.environ.copy();e['PATH']='/home/simon/.nvm/versions/node/v24.22.0/bin:'+e['PATH']
for name in ['GH_TOKEN','GITHUB_TOKEN','VSCODE_DEV','ELECTRON_RUN_AS_NODE']:e.pop(name,None)
h=p/'numeric-control-harness';plans=[]
for topology in ['node','renderer']:
 name='proxy-factory-independent-plumbing-'+topology;command=['python3',str(h/('perf-pairs.py' if topology=='node' else 'perf-electron-pairs.py')),'--root',original['control']['root'],'--runtime-map',str(mapfile),'--output',str(p/name),'--variants','control,proxy-method-factory','--fixtures','primitive,small-object','--replicates','1','--iterations','64','--warmup','128','--concurrency','32','--handler','sync'];plans.append({'name':name,'command':command,'plumbingOnly':True})
for scope,handler,concurrency,fixtures,iterations,warmup in [('ordinary','sync',32,'primitive,small-object',32768,16384),('deferred','deferred',32,'primitive',8192,8192),('sequential','sync',1,'primitive',16384,8192)]:
 for kind,reps,variants in [('aa10',10,'control,same-aa'),('final50',50,'control,proxy-method-factory')]:
  for topology in ['node','renderer']:
   name=f'proxy-factory-independent-{scope}-{kind}-{topology}';command=['python3',str(h/('perf-pairs.py' if topology=='node' else 'perf-electron-pairs.py')),'--root',original['control']['root'],'--runtime-map',str(mapfile),'--output',str(p/name),'--variants',variants,'--fixtures',fixtures,'--replicates',str(reps),'--iterations',str(iterations),'--warmup',str(warmup),'--concurrency',str(concurrency),'--handler',handler];plans.append({'name':name,'command':command,'plumbingOnly':False})
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'running-serial-independent-proxy-confirmation','scope':r['scope'],'plans':plans,'completed':[],'unprofiledProcesses':960,'plumbingProcesses':8}
def save():marker.write_text(json.dumps(record,indent=2)+'\n')
save()
try:
 for case in plans:
  print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'BEGIN',case['name'],flush=True)
  with (p/(case['name']+'.log')).open('x') as log:subprocess.run(case['command'],env=e,cwd=p,stdout=log,stderr=log,check=True)
  record['completed'].append(case['name']);save();print(datetime.datetime.now(datetime.timezone.utc).isoformat(),'DONE',case['name'],flush=True)
 record['state']='completed-independent-proxy-confirmation-await-review';save()
except BaseException as error:
 record['state']='held-preserve-all-proxy-confirmation-partials-no-automatic-repeat';record['errorClass']=type(error).__name__;save();print(record['state'],record['errorClass'],flush=True)

with (p/'proxy-factory-independent-root-review.log').open('x') as review_log:
 subprocess.run(['python3',str(p/'wait-counterfree-root-review.py'),'--stage','proxy-factory-independent'],cwd=p,env=e,stdout=review_log,stderr=review_log,check=True)
