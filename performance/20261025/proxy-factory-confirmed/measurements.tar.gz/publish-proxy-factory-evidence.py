from pathlib import Path
import os,json,hashlib,subprocess,datetime,fcntl
p=Path('/home/simon/.cache/ipc-opt-20261025');v=Path('/home/simon/.cache/vscode-ipc-opt-20261022');lock=(p/'proxy-factory-evidence-publication.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
marker=p/'proxy-factory-evidence-published.json';intent=p/'proxy-factory-evidence-publication-intent.json';assert not marker.exists() and not intent.exists(),'Preserve previous transaction; reconcile rather than repeat'
gap=json.loads((p/'proxy-factory-independent-root-review.json').read_text());assert gap['state']=='ready-counterfree-root-review' and not (p/'proxy-factory-independent-root-review-release.json').exists();assert datetime.datetime.fromisoformat(gap['deadlineUTC'])>datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(minutes=5)
for q in Path('/proc').iterdir():
 if not q.name.isdigit():continue
 try:a=(q/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 assert not(a and Path(os.fsdecode(a[0])).name=='perf' and b'stat' in a and any(str(p).encode() in x for x in a)), 'Counterfree publication only'
def sha(f):
 with f.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
m=json.loads((p/'proxy-factory-confirmed-manifest.json').read_text());assert sha(p/'proxy-factory-confirmed.tar.gz')==m['archiveSHA256']
for row in m['files']:assert sha(p/row['path'])==row['sha256'], 'Archived input changed'
text="""# RPC proxy getter allocation optimization

The current `4a7ffd59` RPCProtocol source is byte-for-byte identical to the frozen measured control. The small first-use method factory change in source commit `01727f8ddcdc94276b35b7e417b9c39e49708253` compiles byte-for-byte to the measured candidate (`f27977b35f913f8a952972532ab4b02a3790dfa6da5f1121baab8841201ca80c`). Notification/native-promise metadata, null-prototype caching/overrides and server actor lookup are preserved. Current RPC/MessagePort/serialization/completion tests pass all202 cases, with lint and normal commit hygiene.

This is selected as an allocation optimization. A separate calibrated interval-1 V8 diagnostic has six fresh processes per label/fixture,1000 sequential real MessagePort RPCs after16384 warmup andGC, both peers in one process. Median sampled JS bytes fall2.60% for primitive and1.39% for small-object RPCs. These estimates exclude native/external memory, are not exact allocation counts, and have no CPU-time interpretation. Missing getter frame attribution stays null rather than zero. All24 profiles and totals are retained.

The independent cohort has ten identical-binary A/A pairs and fifty fixed before/after pairs per ordinary/deferred/sequential cell and topology:960 unprofiled processes plus8 plumbing launches. Exactly one of eight total-instruction intervals excludes zero (ordinary renderer primitive,-0.121%); the other seven total and all eight elapsed intervals include zero. Node ordinary primitive kernel instructions rise2.321% [0.804%,4.314%], while total/elapsed are inconclusive. Identical-binary false positives include Node ordinary total-3.627% and sequential total-0.274%; neither is removed. There is no broad CPU, startup, whole-smoke or packaged-API speedup claim, and no multiplication with independent earlier gains. The original52 exploratory comparisons and24 profiles remain separate rather than pooled.

Tables show paired median changes and95% intervals. User/kernel are the original exploratory bootstrap; total/elapsed use conservative sign/order statistics. No multiple-comparison correction.

"""
items={'manifest.json':p/'proxy-factory-confirmed-manifest.json','measurements.tar.gz':p/'proxy-factory-confirmed.tar.gz','original-complete-review.json':p/'proxy-method-factory-complete-review.json','independent-complete-review.json':p/'proxy-factory-independent-complete-review.json','supplementary-total-timing.json':p/'proxy-factory-independent-total-timing-summary.json','allocation-summary.json':p/'proxy-method-factory-allocations/summary.json','current-source-validation.json':p/'proxy-method-factory-current-source-validation.json'}
extra=json.loads((p/'proxy-factory-independent-total-timing-summary.json').read_text())['campaigns']
def cell(d):
 lo,hi=d['intervalPercent'];return f"{d['medianPairedChangePercent']:+.3f}% [{lo:+.3f},{hi:+.3f}]"+(' (inconclusive)' if d['inconclusive'] else '')
for kind,title in [('final50','Independent fixed50 comparisons'),('aa10','Identical-binary A/A controls')]:
 text+='## '+title+'\n\n| Cell | Fixture | User instructions | Kernel instructions | Total instructions | Elapsed |\n| --- | --- | --- | --- | --- | --- |\n'
 for case in m['campaigns']:
  if case['cohort']!='independent' or case['plumbingOnly'] or kind not in case['campaign']:continue
  root=p/case['campaign'];d=json.loads((root/'summary.json').read_text());label='same-aa' if kind=='aa10' else 'proxy-method-factory';items[case['campaign']+'.summary.json']=root/'summary.json'
  for fixture,row in d['fixtures'].items():
   x=extra[case['campaign']][fixture];values=[row['instructions:u']['comparisons'][label],row['instructions:k']['comparisons'][label],x['userPlusKernelInstructions'],x['elapsedMs']];text+='| '+' | '.join([case['campaign'].replace('proxy-factory-independent-',''),fixture,*map(cell,values)])+' |\n'
 text+='\n'
text+='Archive SHA-256: `'+m['archiveSHA256']+'`. Complete source, frozen-input hashes, all raw results/counters/process logs, both cohorts, semantic probes and allocation profiles are archived. Named runtime caches are excluded.\n'
readme=p/'proxy-factory-evidence-readme.md';readme.write_text(text);items['README.md']=readme
branch='perf/ipc-evidence-20261025';folder='performance/20261025/proxy-factory-confirmed';e=os.environ.copy();e.pop('GH_TOKEN',None);e.pop('GITHUB_TOKEN',None);parent=subprocess.check_output(['git','rev-parse','refs/heads/'+branch],cwd=v,text=True).strip();assert not subprocess.check_output(['git','ls-tree',parent,folder],cwd=v,text=True).strip();assert ': lfs' not in subprocess.check_output(['git','check-attr','filter','--',*[folder+'/'+name for name in items]],cwd=v,text=True)
index=p/'proxy-factory-evidence.index';assert not index.exists();e['GIT_INDEX_FILE']=str(index);subprocess.run(['git','read-tree',parent],cwd=v,env=e,check=True)
for name,file in items.items():
 blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=v,input=file.read_bytes()).decode().strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,folder+'/'+name],cwd=v,env=e,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=v,env=e,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',parent],cwd=v,env=e,input='Archive proxy allocation and independent CPU comparisons with all controls\n',text=True).strip();changes=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',commit],cwd=v,text=True).splitlines();assert len(changes)==len(items) and all(x.startswith(folder+'/') for x in changes)
e.pop('GIT_INDEX_FILE');e['GH_TOKEN']=subprocess.check_output(['gh','auth','token','--user','SimonSiefke'],text=True).strip();e['GIT_LFS_SKIP_PUSH']='1';g=['git','-c','credential.helper=','-c','credential.helper=!gh auth git-credential'];remote=subprocess.check_output([*g,'ls-remote','https://github.com/SimonSiefke/vscode.git','refs/heads/'+branch],cwd=v,env=e,text=True).split()[0];assert remote==parent
status={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'single-append-only-evidence-push-intent','commit':commit,'parent':parent,'folder':folder,'archiveSHA256':m['archiveSHA256'],'counts':m['counts'],'allocationProfiles':24};intent.write_text(json.dumps(status,indent=2)+'\n');subprocess.run(['git','update-ref','refs/heads/'+branch,commit,parent],cwd=v,check=True);subprocess.run([*g,'push','https://github.com/SimonSiefke/vscode.git','refs/heads/'+branch+':refs/heads/'+branch],cwd=v,env=e,check=True)
status['state']='published-existing-evidence-branch-no-pr-operation';marker.write_text(json.dumps(status,indent=2)+'\n');print('Published proxy allocation/independent evidence',commit,flush=True)
