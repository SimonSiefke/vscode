from pathlib import Path
import datetime, fcntl, json, os, subprocess
p = Path('/home/simon/.cache/ipc-opt-20261025')
lock = (p / 'proxy-factory-recovery.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
marker = p / 'proxy-factory-recovery.json'
assert not marker.exists(), 'Preserve prior recovery/prototype samples; reconcile before retry'
assert json.loads((p / 'context-composition-validation.json').read_text())['state'] == 'private-candidate-validated-pushed-original-feature-restored'
for name in ['proxy-method-factory-runtimes.json', 'proxy-method-factory-allocations', 'proxy-method-factory-runtime']:
    assert not (p / name).exists(), 'Original proxy stage must have stopped before any prototype work'
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        args = (proc / 'cmdline').read_bytes().split(b'\0')
    except OSError:
        continue
    assert not (args and Path(os.fsdecode(args[0])).name == 'perf' and b'stat' in args and any(str(p).encode() in arg for arg in args))
record = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': 'first-actual-proxy-experiment-recovery-started',
          'scope': 'Original proxy queue stopped in its source-validation preamble before any prototype compile/probe/allocation/counter. Source validation now completed separately; resume the unchanged experiment once after provider completes, before constructor experiments. No repeated samples or frozen input changes.'}
marker.write_text(json.dumps(record, indent=2) + '\n')
with (p / 'proxy-method-factory-recovered-controller.log').open('x') as log:
    result = subprocess.run(['python3', str(p / 'queue-proxy-method-factory-pilots.py')], cwd=p, stdout=log, stderr=log)
text = (p / 'proxy-method-factory-recovered-controller.log').read_text()
record['exit'] = result.returncode
record['state'] = 'completed-first-actual-proxy-experiment' if result.returncode == 0 and 'All proxy method factory pilots complete' in text else 'held-preserve-proxy-partials-no-automatic-repeat'
marker.write_text(json.dumps(record, indent=2) + '\n')
print(record['state'], flush=True)
