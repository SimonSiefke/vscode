# Focused IPC measurements

These scripts load explicit compiled VS Code protocol variants from `--root`. They do not modify a VS Code checkout. Run timing and allocation collection separately, on an otherwise idle machine. Each result records the runtime, product buffer pool, compiled module hashes, seed, samples and raw data.

`run.py` compares real RPC protocols over Node worker-thread MessagePorts and Electron renderer/utility-process MessagePorts. It randomizes fixture/variant order within each block, warms each fixture, validates returned values and retains all controls. Samples within one process are correlated: use fresh-process repetitions before selecting a change. The direct-clone variant is an experiment on clone-safe fixtures, not a production codec or a guarantee of legacy JSON semantics.

`allocations.mjs` runs a fixed number of real MessagePort RPC calls with V8 allocation sampling including objects collected by minor and major GC. Sampling estimates allocated bytes; it does not measure retained heap or wall-clock speed. The disposable tracker separately counts exact disposable constructions. Both peers run in one process so the profile covers sender and receiver. This is a diagnostic topology; timing uses separate workers/processes.

Example:

```sh
python3 scripts/ipc-benchmark/run.py --root /path/to/vscode --output /path/to/results --blocks 8 --iterations 512
```

Allocation collection takes `IPC_OPT_BENCH_OPTIONS` JSON containing `root`, compiled `module`, `fixture` (`primitive` or `small-object`) and `iterations`, plus an `OUTPUT` file path. Launch Node with `--import ./scripts/ipc-benchmark/product-pool.mjs` to match the Linux product's 8 KiB Buffer pool. Never compare profiled elapsed times with unprofiled timing results.
