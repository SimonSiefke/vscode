import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { comparePairs } from '/home/simon/.cache/ipc-performance-driver-20261025/packages/large-benchmark/src/parts/Statistics/Statistics.ts';
const p='/home/simon/.cache/ipc-opt-20261025';
const startup=[];
for(const directory of fs.readdirSync(path.join(p,'scalar-startup-results')).sort()) {
 const file=path.join(p,'scalar-startup-results',directory,'result.json');
 if(!directory.startsWith('large-result-pair-')||!fs.existsSync(file))continue;
 const r=JSON.parse(fs.readFileSync(file));
 const before=[],after=[];
 const failures=r.samples.filter(s=>s.status!=='success');
 assert.equal(failures.length,0);
 for(let pair=0;pair<50;pair++){
  for(const [revision,values] of [['before',before],['after',after]]){
   const rows=r.samples.filter(s=>s.pair===pair&&s.revision===revision);
   assert.equal(rows.length,1);
   const metric=rows[0].metrics.find(m=>m.name==='startupTime');assert(metric);values.push(metric.value);
  }
 }
 startup.push({benchmark:r.benchmark,commits:r.commits,status:r.status,failures,median:comparePairs(before,after,'median'),mean:comparePairs(before,after,'mean')});
}
assert.equal(startup.length,4);
fs.writeFileSync(path.join(p,'scalar-startup50-summary.json'),JSON.stringify({source:'official Statistics.ts comparePairs; no excluded samples',results:startup},null,2));
console.log(startup.map(r=>({benchmark:r.benchmark.id,percent:r.median.percentChange,intervalMs:r.median.interval,inconclusive:r.median.inconclusive,before:r.median.before.median,after:r.median.after.median})));
