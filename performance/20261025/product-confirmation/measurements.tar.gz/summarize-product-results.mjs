import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { comparePairs } from '/home/simon/.cache/ipc-performance-driver-20261025/packages/large-benchmark/src/parts/Statistics/Statistics.ts';
const p='/home/simon/.cache/ipc-opt-20261025';
const startup=[];
for(const directory of fs.readdirSync(path.join(p,'raw-startup-results')).sort()) {
 const file=path.join(p,'raw-startup-results',directory,'result.json');
 if(!directory.startsWith('large-result-pair-')||!fs.existsSync(file))continue;
 const r=JSON.parse(fs.readFileSync(file));
 const before=[],after=[];
 const failures=r.samples.filter(s=>s.status!=='success');
 assert.equal(failures.length,0);
 for(let pair=0;pair<50;pair++){
  for(const [revision,values] of [['before',before],['after',after]]){
   const rows=r.samples.filter(s=>s.pair===pair&&s.revision===revision);
   assert.equal(rows.length,1);
   const metric=rows[0].metrics.find(m=>m.name==='startupTime');assert(metric);values.push(metric.value);
  }
 }
 startup.push({benchmark:r.benchmark,commits:r.commits,status:r.status,failures,median:comparePairs(before,after,'median'),mean:comparePairs(before,after,'mean')});
}
assert.equal(startup.length,4);
fs.writeFileSync(path.join(p,'raw-startup50-summary.json'),JSON.stringify({source:'official Statistics.ts comparePairs; no excluded samples',results:startup},null,2));
console.log(startup.map(r=>({benchmark:r.benchmark.id,percent:r.median.percentChange,intervalMs:r.median.interval,inconclusive:r.median.inconclusive,before:r.median.before.median,after:r.median.after.median})));
const smoke=JSON.parse(fs.readFileSync(path.join(p,'raw-functional-smoke-results/paired-smoke-results/paired-smoke-result.json')));
const results=smoke.pairs[0].results;
console.log(Object.keys(results.before.samples[0]));
const a=results.before.samples[0],b=results.after.samples[0];
assert.deepEqual(a.tests,b.tests);
const out={commits:smoke.commits,requestedPairs:smoke.requestedPairs,sameTests:true,before:a,after:b,interpretation:'Single pair compatibility check; elapsed duration is not a performance estimate.'};
fs.writeFileSync(path.join(p,'raw-functional-smoke-summary.json'),JSON.stringify(out,null,2));
console.log(JSON.stringify({before:a,after:b},(k,v)=>k==='tests'?`<${v.length} test names>`:v,2));
