from pathlib import Path
import os,json,subprocess,datetime,statistics,hashlib
p=Path('/home/simon/.cache/ipc-opt-20261025');cal=json.loads((p/'allocation-sampling-calibration/summary.json').read_text());assert cal['passed'] is True;e=os.environ.copy();e['PATH']='/home/simon/.nvm/versions/node/v24.22.0/bin:'+e['PATH'];mapping=json.loads((p/'combined-owned-runtimes.json').read_text());script=p/'combined-owned-allocations.mjs';output=p/'combined-owned-highres-allocations';output.mkdir(exist_ok=False);rows=[]
for replicate in range(6):
 for fixture in ['primitive','small-object']:
  variants=list(mapping);order=variants[replicate%3:]+variants[:replicate%3]
  if replicate>=3:order.reverse()
  for variant in order:
   label=f'{replicate}-{fixture}-{variant}';options={**mapping[variant],'fixture':fixture,'iterations':1000,'warmup':16384,'samplingInterval':1,'collectGarbageBeforeSampling':True};env={**e,'IPC_OPT_BENCH_OPTIONS':json.dumps(options),'OUTPUT':str(output/(label+'.json'))}
   with(output/(label+'.log')).open('w')as log:subprocess.run(['node','--import',str(p/'native-promise-harness/product-pool.mjs'),str(script)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
   result=json.loads((output/(label+'.json')).read_text());assert result['measuredLogicalCalls']==1000 and result['samplingInterval']==1;rows.append({'replicate':replicate,'fixture':fixture,'variant':variant,'estimatedBytesPerCall':result['sampledBytesPerCall'],'recordedSamples':len(result['profile']['samples']),'trackedDisposableConstructions':result['trackedDisposableConstructions'],'traffic':result['traffic']});print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,result['sampledBytesPerCall'],flush=True)
summary={'diagnosticOnly':True,'scope':'Calibrated high-resolution V8 JS heap sampling, interval1; transient objects collected by minor/majorGC included. Both real MessagePort peers in one process, six independent processes per label/fixture,1000 measured sequential RPCs after16384warmup and fullGC before sampling. Values/actualremoteexecutedcalls validated. Profiling overhead and native/external allocations excluded from performance estimates. Not an exact allocation census; no concurrent batching claim. Separate from interval1024/10kcall diagnostics.','calibration':'allocation-sampling-calibration/summary.json','harnessSHA256':hashlib.sha256(script.read_bytes()).hexdigest(),'samples':rows,'fixtures':{}}
for fixture in ['primitive','small-object']:
 medians={v:statistics.median(r['estimatedBytesPerCall']for r in rows if r['fixture']==fixture and r['variant']==v)for v in mapping};summary['fixtures'][fixture]={'medianEstimatedBytesPerCall':medians,'relativeChangePercent':{v:(value/medians['control']-1)*100 for v,value in medians.items()if v!='control'}}
(output/'summary.json').write_text(json.dumps(summary,indent=2));print('High-resolution allocation diagnostics complete',flush=True)
