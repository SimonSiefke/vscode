from pathlib import Path
import os,subprocess,json,statistics
p=Path('/home/simon/.cache/ipc-opt-20261025');output=p/'allocation-sampling-calibration';output.mkdir(exist_ok=False);e=os.environ.copy();e['PATH']='/home/simon/.nvm/versions/node/v24.22.0/bin:'+e['PATH'];rows=[]
for replicate in range(3):
 for count,width in [(0,128),(4096,64),(4096,128),(8192,128)]:
  name=f'{replicate}-{count}-{width}';env={**e,'IPC_ALLOCATION_CALIBRATION':json.dumps({'count':count,'width':width}),'OUTPUT':str(output/(name+'.json'))}
  with(output/(name+'.log')).open('w')as log:subprocess.run(['node',str(p/'calibrate-allocation-sampling.mjs')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=60)
  row=json.loads((output/(name+'.json')).read_text());assert row['bytes']>=row['minimumElementBytes'];assert row['samples']>=count;rows.append({'replicate':replicate,**{k:v for k,v in row.items()if k!='profile'}})
get=lambda count,width:statistics.median(row['bytes']for row in rows if row['options']=={'count':count,'width':width})
noop=get(0,128);ratio=(get(8192,128)-noop)/(get(4096,128)-noop);slot=rows[0]['pointerBytes'];widthDelta=get(4096,128)-get(4096,64);expectedWidthDelta=4096*64*slot;assert 1.97<=ratio<=2.03,ratio;assert abs(widthDelta/expectedWidthDelta-1)<=.03,(widthDelta,expectedWidthDelta)
summary={'diagnosticOnly':True,'passed':True,'scope':'High-resolution V8 heap sampling interval1, collected-object records retained. Near-census JS allocation diagnostic, not a native/external allocator census or CPU/timing measure. Engine clamps sampling steps to tagged-word size and still uses random intervals; do not call exact. Calibration retains a64-array escape ring, validates execution, checks doubling iteration count and element storage growth against actual pointer size, withthreefreshprocesses percase.','noOpMedianBytes':noop,'doublingCountRatio':ratio,'observedWidthDeltaBytes':widthDelta,'expectedElementWidthDeltaBytes':expectedWidthDelta,'rows':rows};(output/'summary.json').write_text(json.dumps(summary,indent=2));print('Sampling calibration passed',ratio,widthDelta,expectedWidthDelta)
