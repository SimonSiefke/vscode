from pathlib import Path
import os,json,subprocess,datetime,hashlib
p=Path('/home/simon/.cache/ipc-opt-20261025');v=Path('/home/simon/.cache/vscode-ipc-opt-20261022');branch='perf/ipc-evidence-20261025';folder='performance/20261025/combined-allocation-diagnostics'
assert not (p/'allocation-evidence-published.json').exists()
manifest=json.loads((p/'combined-allocation-diagnostics-manifest.json').read_text())
assert hashlib.sha256((p/'combined-allocation-diagnostics.tar.gz').read_bytes()).hexdigest()==manifest['archiveSHA256']
for record in manifest['files']:
 assert hashlib.sha256((p/record['path']).read_bytes()).hexdigest()==record['sha256'], 'Allocation evidence input changed after archival'

hi=json.loads((p/'combined-owned-highres-allocations/summary.json').read_text());low=json.loads((p/'combined-owned-allocations/summary.json').read_text());cal=json.loads((p/'allocation-sampling-calibration/summary.json').read_text())
text='''# RPC allocation diagnostics

These sampled JavaScript heap allocation diagnostics are separate from CPU, elapsed, startup and full smoke-suite measurements. Both real Node MessagePort peers run in one process. There are six independent processes per label and fixture, with exact remote execution counts and returned values checked. Every label and sample is retained.

The preferred high-resolution diagnostic samples at interval 1 after 16,384 warmup RPCs and full GC, then 1,000 measured sequential RPCs. Collected-object records are included. V8 still samples and clamps steps to tagged-word size: this is not an exact allocation census, and it excludes native/external allocations. Profiler overhead prevents treating these runs as CPU/elapsed estimates. No concurrent batching benefit is inferred.

| Fixture | Control bytes/call | Owned batch core | Core + scalar arguments | Scalar core change |
| --- | ---: | ---: | ---: | ---: |
'''
for fixture,row in hi['fixtures'].items():
 med=row['medianEstimatedBytesPerCall'];change=row['relativeChangePercent']['combined-scalar-arguments-owned'];text+=f"| {fixture} | {med['control']:.3f} | {med['combined-owned']:.3f} | {med['combined-scalar-arguments-owned']:.3f} | {change:+.2f}% |\n"
text+='''
These are medians of six fresh processes per cell; no confidence interval or universal performance claim is supplied. The archive also preserves the separate interval-1024 diagnostic (1,000 warmup, 10,000 measured calls). Its results are not pooled with the interval-1 results or selected to maximize the reported gain.

Calibration uses three fresh processes per case, a no-op control, doubled array count, and doubled element width. An escape ring keeps live and collected objects represented. The expected element-width delta uses the actual runtime's tagged-word size.

'''
text+=f"Observed count-doubling ratio: {cal['doublingCountRatio']:.9f}. Observed element-width delta: {cal['observedWidthDeltaBytes']} bytes; expected: {cal['expectedElementWidthDeltaBytes']} bytes. Runtime is Node 24.22.0 / V8 13.6.233.17-node.57; no engine upgrade is used for the metric.\n\n"
text+='The archive contains all 72 RPC and 12 calibration raw profiles/results, their logs, metric scripts and research notes, and exact core IPC/event/buffer module bytes/hashes. It is a diagnostic evidence bundle, not a standalone VS Code build. Source and compiled core identities are distinct from the current merged-base packaged application campaigns. Observed-promise metadata is enabled identically across labels.\n\nArchive SHA-256: `'+manifest['archiveSHA256']+'`.\n'
readme=p/'allocation-evidence-readme.md';readme.write_text(text)
e=os.environ.copy();e.pop('GH_TOKEN',None);e.pop('GITHUB_TOKEN',None)
parent=subprocess.check_output(['git','rev-parse','refs/heads/'+branch],cwd=v,text=True).strip()
assert not subprocess.check_output(['git','ls-tree',parent,folder],cwd=v,text=True).strip(),'Evidence destination already exists'
index=p/'allocation-evidence.index';assert not index.exists(),'Preserve interrupted index; no automatic retry'
e['GIT_INDEX_FILE']=str(index);subprocess.run(['git','read-tree',parent],cwd=v,env=e,check=True)
items={'README.md':readme,'manifest.json':p/'combined-allocation-diagnostics-manifest.json','measurements.tar.gz':p/'combined-allocation-diagnostics.tar.gz','interval1.summary.json':p/'combined-owned-highres-allocations/summary.json','interval1024.summary.json':p/'combined-owned-allocations/summary.json','calibration.summary.json':p/'allocation-sampling-calibration/summary.json'}
for name,f in items.items():
 blob=subprocess.check_output(['git','hash-object','-w','--stdin'],cwd=v,input=f.read_bytes()).decode().strip();subprocess.run(['git','update-index','--add','--cacheinfo','100644',blob,folder+'/'+name],cwd=v,env=e,check=True)
tree=subprocess.check_output(['git','write-tree'],cwd=v,env=e,text=True).strip();commit=subprocess.check_output(['git','commit-tree',tree,'-p',parent],cwd=v,env=e,input='Archive calibrated RPC JavaScript allocation diagnostics\n',text=True).strip()
changes=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',commit],cwd=v,text=True).splitlines();assert len(changes)==len(items) and all(x.startswith(folder+'/') for x in changes)
e.pop('GIT_INDEX_FILE');e['GH_TOKEN']=subprocess.check_output(['gh','auth','token','--user','SimonSiefke'],text=True).strip();e['GIT_LFS_SKIP_PUSH']='1'
git=['git','-c','credential.helper=','-c','credential.helper=!gh auth git-credential']
remote=subprocess.check_output(git+['ls-remote','https://github.com/SimonSiefke/vscode.git','refs/heads/'+branch],cwd=v,env=e,text=True).split()[0];assert remote==parent,'Remote evidence advanced; preserve prepared commit/index and review before retry'
subprocess.run(['git','update-ref','refs/heads/'+branch,commit,parent],cwd=v,check=True)
subprocess.run(git+['push','https://github.com/SimonSiefke/vscode.git','refs/heads/'+branch+':refs/heads/'+branch],cwd=v,env=e,check=True)
status={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':commit,'parent':parent,'folder':folder,'archiveSHA256':manifest['archiveSHA256'],'diagnosticOnly':True,'rawRPCSamples':72,'calibrationSamples':12}
(p/'allocation-evidence-published.json').write_text(json.dumps(status,indent=2)+'\n');f=p/'progress-current.json';d=json.loads(f.read_text());d['evidenceHead']=commit;d['allocationEvidence']=status;d['updatedUTC']=status['utc'];f.write_text(json.dumps(d,indent=2)+'\n');print('Published allocation evidence',commit,flush=True)
