# Allocation measurement choices

The frozen runtime is Node24.22.0 / V8 13.6.233.17-node.57. Its getHeapStatistics result does not expose the newer total_allocated_bytes field documented on Node main. Do not change the benchmark engine just to obtain that field.

The exact-version GC tracer derives allocated from object-heap sizes at adjacent GC boundaries; it is not a public cumulative allocator counter. External/native storage and concurrent collection details make it unsuitable as an exact universal byte counter. Source: https://github.com/nodejs/node/blob/v24.22.0/deps/v8/src/heap/gc-tracer.cc (download checksum in allocation-metric-source.json).

The existing interval1024 V8 sampling diagnostic remains useful for stack attribution. A second interval1 diagnostic is prepared, not yet calibrated or run. V8 clamps sampling steps to tagged-word size and retains probabilistic sampling; interval1 is high-resolution, not an exact allocation census. Both collected-object retention options remain enabled. Source: https://github.com/nodejs/node/blob/v24.22.0/deps/v8/src/profiler/sampling-heap-profiler.cc .

Before RPC runs, three fresh processes per controlled array-allocation case must validate increasing byte volume with doubled iterations and increased element storage, including a no-op control. If calibration fails, retain the logs and withhold this new metric; do not reinterpret the failed calibration as a performance result. If it passes, six fresh processes per variant/fixture run1000 sequential RPCs after16384warmup and fullGC before profiling. All profiles validate returned values and exact remote call counts. No high-resolution profile is part of a CPU/timing comparison. Native/external allocations and concurrent batching remain outside this diagnostic's claims.
