from pathlib import Path
import json,hashlib,tarfile,datetime,os
p=Path('/home/simon/.cache/ipc-opt-20261025')
assert 'All current packaged confirmations and startup profiles complete' in (p/'current-product-confirmation-promoted.log').read_text()
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:args=(proc/'cmdline').read_bytes().split(b'\0')
 except OSError:continue
 assert not(args and Path(os.fsdecode(args[0])).name=='perf' and b'stat' in args and any(str(p).encode() in a for a in args)),'Defer archive whileownedcountersactive'
archive=p/'combined-allocation-diagnostics.tar.gz';assert not archive.exists()
cal=json.loads((p/'allocation-sampling-calibration/summary.json').read_text());assert cal['passed'] is True
files=[]
for campaign,expected in [('combined-owned-allocations',36),('combined-owned-highres-allocations',36),('allocation-sampling-calibration',12)]:
 folder=p/campaign;summary=json.loads((folder/'summary.json').read_text());raw=[x for x in folder.glob('*.json') if x.name!='summary.json'];assert len(raw)==expected,(campaign,len(raw))
 for f in raw:
  r=json.loads(f.read_text())
  if campaign.startswith('combined-owned'):
   assert r['measuredLogicalCalls']==(1000 if 'highres' in campaign else 10000)
   assert r['includesCollectedObjects'] is True
   if 'highres' in campaign:assert r['samplingInterval']==1 and r['options']['warmup']==16384
  files.append(f)
 files += sorted(folder.glob('*.log'))+[folder/'summary.json']
for name in ['combined-owned-allocations.mjs','run-highres-rpc-allocations.py','run-allocation-sampling-calibration.py','calibrate-allocation-sampling.mjs','allocation-metric-notes.md','combined-owned-runtimes.json','native-promise-harness/product-pool.mjs','prepare-allocation-evidence.py','publish-allocation-evidence.py']:
 f=p/name;assert f.is_file(),name;files.append(f)
# Archive core measured IPC/event/buffer modules by exact bytes/hash; this is not a complete standalone VS Code build.
for name,entry in json.loads((p/'combined-owned-runtimes.json').read_text()).items():
 root=Path(entry['root']);assert root.is_relative_to(p)
 for relative in [entry['module'],'vs/workbench/services/extensions/common/rpcMessagePort.js','vs/workbench/services/extensions/common/proxyIdentifier.js','vs/base/common/event.js','vs/base/common/lifecycle.js','vs/base/common/buffer.js']:
  f=root/'out'/relative;assert f.is_file();files.append(f)
files=sorted(set(files))
records=[{'path':str(f.relative_to(p)),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in files]
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for f in files:tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'diagnosticOnly':True,'archiveSHA256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archiveBytes':archive.stat().st_size,'rawRPCSamples':72,'calibrationSamples':12,'runtime':'Node24.22.0/V8 13.6 frozen core runtimes, same realMessagePort pair inoneprocess','scope':'V8 sampled JavaScript heap allocation with objects collected byminor/majorGC included; not exact/native/external allocation census. No CPU/walltime benefit inferred. Interval1024 andcalibratedinterval1 retain distinctwarmup/iterationcounts andall labels; nofiltering.','files':records}
(p/'combined-allocation-diagnostics-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared allocation archive',manifest['archiveBytes'],len(files),flush=True)
